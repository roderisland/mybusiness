<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;

class DatabaseController extends Controller
{
    public function index()
    {
        $dbName = config('database.connections.mysql.database');
        $tables = DB::select('SHOW TABLE STATUS');
        $totalSize = 0;
        $tableList = [];
        foreach ($tables as $t) {
            $size = ($t->Data_length ?? 0) + ($t->Index_length ?? 0);
            $totalSize += $size;
            $tableList[] = ['name'=>$t->Name,'engine'=>$t->Engine,'rows'=>$t->Rows,'size'=>$size,'collation'=>$t->Collation,'auto_increment'=>$t->Auto_increment,'created'=>$t->Create_time,'updated'=>$t->Update_time];
        }
        return view('admin.pages.database.index', compact('dbName','tableList','totalSize'));
    }

    public function viewTable($table)
    {
        $this->validateTableName($table);
        $columns = DB::select("SHOW FULL COLUMNS FROM `{$table}`");
        $indexes = DB::select("SHOW INDEX FROM `{$table}`");
        $cnt = DB::select("SELECT COUNT(*) as cnt FROM `{$table}`");
        $totalRows = $cnt[0]->cnt ?? 0;
        $perPage = 50;
        $page = max(1,(int)request('page',1));
        $offset = ($page-1)*$perPage;
        $rows = DB::select("SELECT * FROM `{$table}` LIMIT {$perPage} OFFSET {$offset}");
        $totalPages = max(1,(int)ceil($totalRows/$perPage));
        $status = DB::select("SHOW TABLE STATUS LIKE '{$table}'");
        $tableInfo = $status[0] ?? null;
        $createResult = DB::select("SHOW CREATE TABLE `{$table}`");
        $createSql = $createResult[0]->{'Create Table'} ?? '';
        return view('admin.pages.database.table', compact('table','columns','indexes','rows','totalRows','page','perPage','totalPages','tableInfo','createSql','offset'));
    }

    public function query(Request $request)
    {
        $sql = $request->input('sql','');
        $results = null; $error = null; $affectedRows = null; $executionTime = null; $columns = [];
        if ($request->isMethod('post') && !empty($sql)) {
            $sql = trim($sql);
            foreach (['DROP DATABASE','GRANT ','REVOKE ','CREATE USER','DROP USER'] as $b) {
                if (stripos($sql,$b)!==false) {
                    $error = "Blocked: '{$b}' not allowed.";
                    return view('admin.pages.database.query', compact('sql','results','error','affectedRows','executionTime','columns'));
                }
            }
            $start = microtime(true);
            try {
                $upper = strtoupper(ltrim($sql));
                if (str_starts_with($upper,'SELECT')||str_starts_with($upper,'SHOW')||str_starts_with($upper,'DESCRIBE')||str_starts_with($upper,'EXPLAIN')) {
                    $results = DB::select($sql);
                    if (!empty($results)) $columns = array_keys((array)$results[0]);
                } else {
                    $affectedRows = DB::affectingStatement($sql);
                }
            } catch (\Exception $e) { $error = $e->getMessage(); }
            $executionTime = round((microtime(true)-$start)*1000,2);
        }
        return view('admin.pages.database.query', compact('sql','results','error','affectedRows','executionTime','columns'));
    }

    public function export(Request $request)
    {
        if ($request->isMethod('post')) {
            $selectedTables = $request->input('tables',[]);
            $includeStructure = $request->boolean('include_structure',true);
            $includeData = $request->boolean('include_data',true);
            set_time_limit(300);
            $dbName = config('database.connections.mysql.database');
            $sql = "-- Database Export: {$dbName}\n-- Generated: ".now()->toDateTimeString()."\n\nSET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';\nSET time_zone='+00:00';\nSET FOREIGN_KEY_CHECKS=0;\n\n";
            $tables = DB::select('SHOW TABLES');
            foreach ($tables as $table) {
                $arr=(array)$table; $tn=reset($arr);
                if (!empty($selectedTables)&&!in_array($tn,$selectedTables)) continue;
                $sql.="-- --------------------------------------------------------\n-- Table: `{$tn}`\n-- --------------------------------------------------------\n\n";
                if ($includeStructure) {
                    $sql.="DROP TABLE IF EXISTS `{$tn}`;\n";
                    $cr=DB::select("SHOW CREATE TABLE `{$tn}`");
                    if(!empty($cr))$sql.=$cr[0]->{'Create Table'}.";\n\n";
                }
                if ($includeData) {
                    $rows=DB::select("SELECT * FROM `{$tn}`");
                    if(!empty($rows)){
                        $cols=array_keys((array)$rows[0]);
                        $colList='`'.implode('`, `',$cols).'`';
                        foreach(array_chunk($rows,100)as$chunk){
                            $sql.="INSERT INTO `{$tn}` ({$colList}) VALUES\n";
                            $vl=[];
                            foreach($chunk as$row){
                                $vals=array_map(fn($v)=>is_null($v)?'NULL':"'".addslashes($v)."'",(array)$row);
                                $vl[]='('.implode(', ',$vals).')';
                            }
                            $sql.=implode(",\n",$vl).";\n\n";
                        }
                    }
                }
            }
            $sql.="SET FOREIGN_KEY_CHECKS=1;\n";
            $filename=$dbName.'_'.now()->format('Y-m-d_His').'.sql';
            $filepath=storage_path('app/'.$filename);
            File::put($filepath,$sql);
            return response()->download($filepath,$filename)->deleteFileAfterSend(true);
        }
        $tables=DB::select('SHOW TABLES');
        $dbName=config('database.connections.mysql.database');
        $tableNames=[];
        foreach($tables as$t){$a=(array)$t;$tableNames[]=reset($a);}
        return view('admin.pages.database.export', compact('tableNames','dbName'));
    }

    public function import(Request $request)
    {
        $result=null;$error=null;
        if($request->isMethod('post')){
            $request->validate(['sql_file'=>'required|file|max:51200']);
            set_time_limit(600);
            try{
                $sql=file_get_contents($request->file('sql_file')->getRealPath());
                DB::statement('SET FOREIGN_KEY_CHECKS=0');
                $stmts=$this->splitSql($sql);$ok=0;$err=0;
                foreach($stmts as$s){
                    $s=trim($s);if(empty($s)||str_starts_with($s,'--')||str_starts_with($s,'/*'))continue;
                    try{DB::unprepared($s);$ok++;}catch(\Exception$e){$err++;}
                }
                DB::statement('SET FOREIGN_KEY_CHECKS=1');
                $result="Import completed: {$ok} statements executed".($err>0?", {$err} errors":'');
            }catch(\Exception$e){$error='Import failed: '.$e->getMessage();}
        }
        return view('admin.pages.database.import', compact('result','error'));
    }

    public function dropTable($table)
    {
        $this->validateTableName($table);
        DB::statement("DROP TABLE IF EXISTS `{$table}`");
        return redirect()->route('admin.database.index')->with('success',"Table `{$table}` dropped.");
    }

    public function truncateTable($table)
    {
        $this->validateTableName($table);
        DB::statement("TRUNCATE TABLE `{$table}`");
        return redirect()->route('admin.database.table',$table)->with('success',"Table `{$table}` truncated.");
    }

    public function deleteRow(Request $request,$table)
    {
        $this->validateTableName($table);
        $where=$request->input('where');
        if($where){DB::delete("DELETE FROM `{$table}` WHERE {$where} LIMIT 1");}
        return redirect()->route('admin.database.table',['table'=>$table,'page'=>$request->input('page',1)])->with('success','Row deleted.');
    }

    protected function validateTableName(string $t):void{if(!preg_match('/^[a-zA-Z0-9_]+$/',$t))abort(404);}

    protected function splitSql(string $sql):array
    {
        $stmts=[];$cur='';$inStr=false;$sc='';
        for($i=0;$i<strlen($sql);$i++){
            $c=$sql[$i];$p=$i>0?$sql[$i-1]:'';
            if($inStr){$cur.=$c;if($c===$sc&&$p!=='\\')$inStr=false;}
            else{if($c==='\''||$c==='"'){$inStr=true;$sc=$c;$cur.=$c;}elseif($c===';'){$t=trim($cur);if(!empty($t))$stmts[]=$t;$cur='';}else{$cur.=$c;}}
        }
        $t=trim($cur);if(!empty($t))$stmts[]=$t;
        return $stmts;
    }
}
