<?php

namespace App\Services;

use App\Models\BackupJob;
use App\Models\BackupRun;
use App\Models\BackupLog;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;

class BackupService
{
    protected BackupRun $run;
    protected string $backupBasePath;

    public function __construct()
    {
        // Store backups in project root /backup directory
        $this->backupBasePath = base_path('backup');
        
        // Ensure base backup directory exists
        if (!File::isDirectory($this->backupBasePath)) {
            File::makeDirectory($this->backupBasePath, 0755, true);
        }
    }

    /**
     * Execute a backup run
     */
    public function execute(BackupRun $run): void
    {
        $this->run = $run;
        $folderName = 'backup_' . now()->format('Y-m-d_His');
        $backupPath = $this->backupBasePath . '/' . $folderName;

        try {
            // Update run status
            $run->update([
                'folder_name' => $folderName,
                'status' => BackupRun::STATUS_RUNNING,
                'started_at' => now(),
            ]);

            // Create backup directory
            if (!File::isDirectory($backupPath)) {
                File::makeDirectory($backupPath, 0755, true);
            }
            File::makeDirectory($backupPath . '/files', 0755, true);

            // ── Log Job Details ──────────────────────────────
            $this->log('info', '════════════════════════════════════════════');
            $this->log('info', 'BACKUP STARTED');
            $this->log('info', '════════════════════════════════════════════');
            $this->log('info', 'Folder: ' . $folderName);
            $this->log('info', 'Job: ' . ($run->job ? $run->job->name : 'Manual Backup'));
            if ($run->job) {
                $this->log('info', 'Frequency: ' . ucfirst($run->job->frequency));
                $this->log('info', 'Retention: Keep last ' . $run->job->retention_count . ' backups');
            }
            $this->log('info', 'Database: ' . ($run->include_database ? 'Yes' : 'No'));
            $this->log('info', 'Base Path: ' . base_path());
            $this->log('info', 'Backup Path: ' . $backupPath);

            // Log include/exclude paths
            $includePaths = $run->include_paths ?? [];
            $excludePaths = $run->exclude_paths ?? [];
            $excludeExtensions = $run->exclude_extensions ?? [];
            
            if (!empty($includePaths)) {
                $this->log('info', 'Include Paths: ' . implode(', ', $includePaths));
            } else {
                $this->log('info', 'Include Paths: [default] app, config, database, resources, routes, storage/app, public');
            }
            if (!empty($excludePaths)) {
                $this->log('info', 'Exclude Paths: ' . implode(', ', $excludePaths));
            }
            if (!empty($excludeExtensions)) {
                $this->log('info', 'Exclude Extensions: ' . implode(', ', $excludeExtensions));
            }
            $this->log('info', '────────────────────────────────────────────');

            // ── Phase 1: Scan Files ──────────────────────────
            $this->log('info', '[Phase 1/3] Scanning files...');
            
            // Debug: check which paths exist
            $resolvedIncludes = empty($includePaths) 
                ? ['app', 'config', 'database', 'resources', 'routes', 'storage/app', 'public']
                : $includePaths;
                
            foreach ($resolvedIncludes as $path) {
                $cleanPath = trim($path, '/');
                if (str_starts_with($cleanPath, 'home/') || str_starts_with($cleanPath, '/')) {
                    $fullPath = '/' . ltrim($cleanPath, '/');
                } else {
                    $fullPath = base_path() . '/' . $cleanPath;
                }
                if (file_exists($fullPath)) {
                    $type = is_dir($fullPath) ? 'DIR' : 'FILE';
                    $this->log('info', "  [{$type}] {$path} → found");
                } else {
                    $this->log('warning', "  [MISSING] {$path} → not found at {$fullPath}");
                }
            }

            $files = $this->collectFiles($includePaths, $excludePaths, $excludeExtensions);
            $totalFiles = count($files);

            // Add 1 for DB dump if included
            $totalCount = $totalFiles + ($run->include_database ? 1 : 0);
            $run->update(['total_files' => $totalCount]);

            $this->log('info', "Scan complete: {$totalFiles} files found");
            $this->log('info', '────────────────────────────────────────────');

            // ── Phase 2: Copy Files ──────────────────────────
            if ($totalFiles > 0) {
                $this->log('info', '[Phase 2/3] Copying files...');
            } else {
                $this->log('warning', '[Phase 2/3] No files to copy — skipping');
            }
            
            $processed = 0;
            $totalSize = 0;
            $currentDir = '';
            $dirFileCount = 0;
            $dirSize = 0;
            $failedFiles = 0;
            $lastLoggedPct = -1;

            foreach ($files as $file) {
                try {
                    $relativePath = $this->getRelativePath($file);
                    $destPath = $backupPath . '/files/' . $relativePath;
                    $destDir = dirname($destPath);

                    if (!File::isDirectory($destDir)) {
                        File::makeDirectory($destDir, 0755, true);
                    }

                    $fileSize = filesize($file);
                    copy($file, $destPath);
                    $totalSize += $fileSize;
                    $processed++;

                    // Track directory-level summary
                    $fileDir = dirname($relativePath);
                    if ($fileDir === '.') $fileDir = '/';
                    
                    if ($fileDir !== $currentDir) {
                        if ($currentDir !== '' && $dirFileCount > 0) {
                            $pct = $totalCount > 0 ? (int) round(($processed / $totalCount) * 100) : 0;
                            $this->log('info', "[{$pct}%] {$currentDir}/ — {$dirFileCount} files (" . $this->formatBytes($dirSize) . ")");
                        }
                        $currentDir = $fileDir;
                        $dirFileCount = 0;
                        $dirSize = 0;
                    }
                    $dirFileCount++;
                    $dirSize += $fileSize;

                    // Update DB progress every 20 files (more frequent for live UI)
                    if ($processed % 20 === 0 || $processed === $totalFiles) {
                        $run->update([
                            'processed_files' => $processed,
                            'total_size' => $totalSize,
                        ]);
                    }

                    // Log milestone every 5% so UI always shows movement
                    $currentPct = $totalCount > 0 ? (int) floor(($processed / $totalCount) * 100) : 0;
                    if ($currentPct >= $lastLoggedPct + 5 && $currentPct > $lastLoggedPct) {
                        // Flush current dir summary at milestone
                        if ($dirFileCount > 0) {
                            $this->log('info', "[{$currentPct}%] {$currentDir}/ — {$dirFileCount} files (" . $this->formatBytes($dirSize) . ")");
                            $dirFileCount = 0;
                            $dirSize = 0;
                        }
                        $this->log('info', "── Progress: {$currentPct}% — {$processed}/{$totalFiles} files, " . $this->formatBytes($totalSize));
                        $lastLoggedPct = $currentPct;
                    }
                } catch (\Exception $e) {
                    $failedFiles++;
                    $this->log('error', "FAILED: {$file} — " . $e->getMessage());
                }
            }

            // Log last directory
            if ($currentDir !== '' && $dirFileCount > 0) {
                $pct = $totalCount > 0 ? (int) round(($processed / $totalCount) * 100) : 0;
                $this->log('info', "[{$pct}%] {$currentDir}/ — {$dirFileCount} files (" . $this->formatBytes($dirSize) . ")");
            }

            if ($totalFiles > 0) {
                $this->log('success', "Files copied: {$processed}/{$totalFiles} (" . $this->formatBytes($totalSize) . ")" . ($failedFiles > 0 ? " — {$failedFiles} failed" : ''));
                $this->log('info', '────────────────────────────────────────────');
            }

            // ── Phase 3: Database Dump ───────────────────────
            if ($run->include_database) {
                $this->log('info', '[Phase 3/3] Dumping database...');
                $dbName = config('database.connections.mysql.database');
                $this->log('info', "Database: {$dbName}");
                $this->dumpDatabase($backupPath);
                $processed++;
                $run->update(['processed_files' => $processed]);
                
                $dbFile = $backupPath . '/database.sql';
                if (File::exists($dbFile)) {
                    $dbSize = filesize($dbFile);
                    $this->log('success', 'Database dump completed (' . $this->formatBytes($dbSize) . ')');
                } else {
                    $this->log('warning', 'Database dump file not created');
                }
                $this->log('info', '────────────────────────────────────────────');
            } else {
                $this->log('info', '[Phase 3/3] Database dump — skipped (not included)');
            }

            // ── Phase 4: Metadata ────────────────────────────
            $metadata = [
                'backup_id' => $run->id,
                'job_id' => $run->job_id,
                'job_name' => $run->job ? $run->job->name : 'Manual',
                'folder_name' => $folderName,
                'created_at' => now()->toIso8601String(),
                'total_files' => $totalFiles,
                'total_size' => $totalSize,
                'include_paths' => $run->include_paths,
                'exclude_paths' => $run->exclude_paths,
                'include_database' => $run->include_database,
                'laravel_version' => app()->version(),
                'php_version' => PHP_VERSION,
            ];
            File::put($backupPath . '/metadata.json', json_encode($metadata, JSON_PRETTY_PRINT));

            // ── Complete ─────────────────────────────────────
            $run->update([
                'status' => BackupRun::STATUS_COMPLETED,
                'total_size' => $totalSize,
                'completed_at' => now(),
            ]);

            $duration = abs($run->started_at->diffInSeconds(now()));
            $this->log('info', '════════════════════════════════════════════');
            $this->log('success', 'BACKUP COMPLETED SUCCESSFULLY');
            $this->log('info', "Files: {$totalFiles} | Size: " . $this->formatBytes($totalSize) . " | Duration: {$duration}s");
            $this->log('info', '════════════════════════════════════════════');

            // Update job
            if ($run->job_id) {
                $job = BackupJob::find($run->job_id);
                if ($job) {
                    $job->update(['last_run_at' => now()]);
                    $this->enforceRetention($job);
                }
            }

        } catch (\Exception $e) {
            $run->update([
                'status' => BackupRun::STATUS_FAILED,
                'error_message' => $e->getMessage(),
                'completed_at' => now(),
            ]);
            $this->log('error', '════════════════════════════════════════════');
            $this->log('error', 'BACKUP FAILED: ' . $e->getMessage());
            $this->log('error', 'File: ' . $e->getFile() . ':' . $e->getLine());
            $this->log('error', '════════════════════════════════════════════');
            throw $e;
        }
    }

    /**
     * Restore from a backup run
     */
    public function restore(BackupRun $run): void
    {
        $this->run = $run;
        $backupPath = $run->getBackupPath();

        if (!File::isDirectory($backupPath)) {
            throw new \Exception("Backup folder not found: {$backupPath}");
        }

        try {
            $run->update(['status' => BackupRun::STATUS_RESTORING]);
            $this->log('info', 'Restore started from: ' . $run->folder_name);

            // Phase 1: Restore files
            $filesPath = $backupPath . '/files';
            if (File::isDirectory($filesPath)) {
                $this->log('info', 'Restoring files...');
                $files = $this->getAllFilesInDir($filesPath);
                $total = count($files);
                $processed = 0;

                foreach ($files as $file) {
                    try {
                        $relativePath = str_replace($filesPath . '/', '', $file);
                        $destPath = base_path($relativePath);
                        $destDir = dirname($destPath);

                        if (!File::isDirectory($destDir)) {
                            File::makeDirectory($destDir, 0755, true);
                        }

                        copy($file, $destPath);
                        $processed++;

                        $this->log('info', "Restoring: {$relativePath}", $relativePath);

                        if ($processed % 10 === 0 || $processed === $total) {
                            $run->update(['processed_files' => $processed]);
                        }
                    } catch (\Exception $e) {
                        $this->log('warning', "Failed to restore: {$file} - " . $e->getMessage());
                    }
                }
                $this->log('success', "Restored {$processed}/{$total} files");
            }

            // Phase 2: Restore database
            $dbDump = $backupPath . '/database.sql';
            if (File::exists($dbDump)) {
                $this->log('info', 'Restoring database...');
                $this->restoreDatabase($dbDump);
                $this->log('success', 'Database restored');
            }

            $run->update([
                'status' => BackupRun::STATUS_RESTORED,
                'completed_at' => now(),
            ]);
            $this->log('success', 'Restore completed successfully');

        } catch (\Exception $e) {
            $run->update([
                'status' => BackupRun::STATUS_FAILED,
                'error_message' => 'Restore failed: ' . $e->getMessage(),
            ]);
            $this->log('error', 'Restore FAILED: ' . $e->getMessage());
            throw $e;
        }
    }

    /**
     * Collect files based on include/exclude paths and extension filters
     */
    protected function collectFiles(array $includePaths, array $excludePaths, array $excludeExtensions = []): array
    {
        $basePath = base_path();
        $files = [];

        if (empty($includePaths)) {
            $includePaths = ['app', 'config', 'database', 'resources', 'routes', 'storage/app', 'public'];
        }

        $defaultExcludes = ['vendor', 'node_modules', 'backup', '.git', 'storage/logs', 'storage/framework/cache', 'storage/framework/sessions', 'storage/framework/views'];
        $allExcludes = array_unique(array_merge($defaultExcludes, $excludePaths));

        // Normalize extensions (remove dots, lowercase)
        $excludeExts = array_map(fn($e) => strtolower(ltrim(trim($e), '.')), $excludeExtensions);

        foreach ($includePaths as $includePath) {
            $includePath = trim($includePath, '/');
            
            if (str_starts_with($includePath, 'home/') || str_starts_with($includePath, '/')) {
                $fullPath = '/' . ltrim($includePath, '/');
            } else {
                $fullPath = $basePath . '/' . $includePath;
            }
            
            if (!file_exists($fullPath)) continue;

            if (is_file($fullPath)) {
                $ext = strtolower(pathinfo($fullPath, PATHINFO_EXTENSION));
                if (!$this->isExcluded($fullPath, $allExcludes, $basePath) && !in_array($ext, $excludeExts)) {
                    $files[] = $fullPath;
                }
                continue;
            }

            if (is_dir($fullPath)) {
                $iterator = new RecursiveIteratorIterator(
                    new RecursiveDirectoryIterator($fullPath, RecursiveDirectoryIterator::SKIP_DOTS),
                    RecursiveIteratorIterator::LEAVES_ONLY
                );

                foreach ($iterator as $file) {
                    if ($file->isFile()) {
                        $ext = strtolower($file->getExtension());
                        if (!$this->isExcluded($file->getPathname(), $allExcludes, $basePath) && !in_array($ext, $excludeExts)) {
                            $files[] = $file->getPathname();
                        }
                    }
                }
            }
        }

        return $files;
    }

    /**
     * Check if a file path matches any exclude pattern
     */
    protected function isExcluded(string $filePath, array $excludePaths, string $basePath): bool
    {
        $relativePath = str_replace($basePath . '/', '', $filePath);
        foreach ($excludePaths as $exclude) {
            $exclude = trim($exclude, '/');
            if (str_starts_with($relativePath, $exclude . '/') || $relativePath === $exclude) {
                return true;
            }
        }
        return false;
    }

    /**
     * Get relative path from base_path
     */
    protected function getRelativePath(string $filePath): string
    {
        return str_replace(base_path() . '/', '', $filePath);
    }

    /**
     * Get all files in a directory recursively
     */
    protected function getAllFilesInDir(string $dir): array
    {
        $files = [];
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::LEAVES_ONLY
        );
        foreach ($iterator as $file) {
            if ($file->isFile()) {
                $files[] = $file->getPathname();
            }
        }
        return $files;
    }

    /**
     * Dump the MySQL database (PHP-only, no shell commands)
     */
    protected function dumpDatabase(string $backupPath): void
    {
        $dumpFile = $backupPath . '/database.sql';
        $this->phpDatabaseDump($dumpFile);

        if (File::exists($dumpFile)) {
            $this->run->update([
                'total_size' => ($this->run->total_size ?? 0) + filesize($dumpFile),
            ]);
        }
    }

    /**
     * PHP-based database dump fallback (when mysqldump not available)
     */
    protected function phpDatabaseDump(string $dumpFile): void
    {
        $tables = DB::select('SHOW TABLES');
        $sql = "-- Database Backup\n-- Generated: " . now()->toDateTimeString() . "\n";
        $sql .= "SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';\nSET time_zone = '+00:00';\nSET FOREIGN_KEY_CHECKS = 0;\n\n";

        foreach ($tables as $table) {
            $tableArray = (array)$table;
            $tableName = reset($tableArray);
            
            // Get CREATE TABLE
            $createResult = DB::select("SHOW CREATE TABLE `{$tableName}`");
            if (!empty($createResult)) {
                $createStmt = $createResult[0]->{'Create Table'} ?? '';
                $sql .= "DROP TABLE IF EXISTS `{$tableName}`;\n";
                $sql .= $createStmt . ";\n\n";
            }

            // Get data
            $rows = DB::select("SELECT * FROM `{$tableName}`");
            if (!empty($rows)) {
                foreach ($rows as $row) {
                    $values = array_map(function ($val) {
                        if (is_null($val)) return 'NULL';
                        return "'" . addslashes($val) . "'";
                    }, (array) $row);
                    $sql .= "INSERT INTO `{$tableName}` VALUES(" . implode(',', $values) . ");\n";
                }
                $sql .= "\n";
            }
        }

        $sql .= "SET FOREIGN_KEY_CHECKS = 1;\n";
        File::put($dumpFile, $sql);
    }

    /**
     * Restore database from SQL dump (PHP-only, no shell commands)
     */
    protected function restoreDatabase(string $dumpFile): void
    {
        $sql = File::get($dumpFile);
        $statements = array_filter(array_map('trim', explode(";\n", $sql)));
        
        DB::statement('SET FOREIGN_KEY_CHECKS = 0');
        foreach ($statements as $statement) {
            $statement = trim($statement, "; \t\n\r");
            if (!empty($statement) && !str_starts_with($statement, '--') && !str_starts_with($statement, '/*')) {
                try {
                    DB::unprepared($statement);
                } catch (\Exception $e) {
                    $this->log('warning', "SQL failed: " . substr($statement, 0, 80));
                }
            }
        }
        DB::statement('SET FOREIGN_KEY_CHECKS = 1');
    }

    /**
     * Enforce retention policy - delete old backups
     */
    public function enforceRetention(BackupJob $job): void
    {
        $retentionCount = $job->retention_count ?? 10;
        $runs = BackupRun::where('job_id', $job->id)
            ->where('status', BackupRun::STATUS_COMPLETED)
            ->orderBy('created_at', 'desc')
            ->skip($retentionCount)
            ->take(100)
            ->get();

        foreach ($runs as $oldRun) {
            $this->deleteBackup($oldRun);
        }
    }

    /**
     * Delete a backup and its files
     */
    public function deleteBackup(BackupRun $run): void
    {
        $backupPath = $run->getBackupPath();
        if ($run->folder_name && File::isDirectory($backupPath)) {
            File::deleteDirectory($backupPath);
        }
        $run->logs()->delete();
        $run->delete();
    }

    /**
     * Log a message for the current run
     */
    protected function log(string $level, string $message, ?string $filePath = null, ?int $fileSize = null): void
    {
        BackupLog::create([
            'run_id' => $this->run->id,
            'level' => $level,
            'message' => $message,
            'file_path' => $filePath,
            'file_size' => $fileSize,
            'logged_at' => now(),
        ]);
    }

    protected function formatBytes(int $bytes): string
    {
        if ($bytes >= 1073741824) return number_format($bytes / 1073741824, 2) . ' GB';
        if ($bytes >= 1048576) return number_format($bytes / 1048576, 2) . ' MB';
        if ($bytes >= 1024) return number_format($bytes / 1024, 2) . ' KB';
        return $bytes . ' B';
    }
}
