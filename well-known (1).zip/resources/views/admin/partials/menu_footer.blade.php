<footer class="footer">
    <div>&copy; {{ date('Y') }} <strong>Admin Portal</strong>. All rights reserved.</div>
    <div>Version 1.0.0</div>
</footer>
