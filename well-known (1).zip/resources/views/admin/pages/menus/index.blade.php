@extends('admin.layouts.app')
@section('title', 'Menu Management')

@section('content')
<div class="page-header">
    <div>
        <h2>Menu Management</h2>
        <p class="page-desc">Drag and drop to reorder menus</p>
    </div>
    <div class="header-actions">
        <button class="btn btn-outline" onclick="openGroupModal()">
            <i class="fas fa-layer-group"></i> New Group
        </button>
        <button class="btn btn-primary" onclick="openMenuModal()">
            <i class="fas fa-plus"></i> New Menu
        </button>
    </div>
</div>

@if(session('success'))
    <div class="alert alert-success">
        <i class="fas fa-check-circle"></i>
        {{ session('success') }}
    </div>
@endif

@if(session('error'))
    <div class="alert alert-danger">
        <i class="fas fa-exclamation-circle"></i>
        {{ session('error') }}
    </div>
@endif

<div class="menu-container">
    @foreach($menuGroups as $group)
    <div class="menu-section">
        <div class="section-header">
            <div class="section-title">
                <span class="section-name">{{ $group->title }}</span>
                <span class="section-badge">{{ $menus->where('group_id', $group->id)->count() }} items</span>
            </div>
            <div class="section-actions">
                <button class="btn-action" onclick="editGroup({{ $group->id }}, '{{ $group->title }}', '{{ $group->slug }}', {{ $group->sort_order }}, {{ $group->is_active }})" title="Edit">
                    <i class="fas fa-pen"></i>
                </button>
                <form action="{{ route('admin.menus.groups.destroy', $group->id) }}" method="POST" style="display:inline;" onsubmit="return confirm('Delete this group?');">
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="btn-action btn-action-danger" title="Delete">
                        <i class="fas fa-trash"></i>
                    </button>
                </form>
            </div>
        </div>
        
        <div class="menu-table">
            <div class="table-header">
                <div class="th-drag"></div>
                <div class="th-title">Menu Item</div>
                <div class="th-route">Route</div>
                <div class="th-key">Permission Key</div>
                <div class="th-status">Status</div>
                <div class="th-actions">Actions</div>
            </div>
            
            <div class="table-body" id="sortable-{{ $group->id }}" data-group-id="{{ $group->id }}">
                @php
                    $groupMenus = $menus->where('group_id', $group->id)->whereNull('parent_id');
                @endphp
                @forelse($groupMenus as $menu)
                <div class="table-row parent-row" data-id="{{ $menu->id }}">
                    <div class="td-drag"><i class="fas fa-grip-vertical"></i></div>
                    <div class="td-title">
                        <div class="menu-icon-box">
                            <i class="{{ $menu->icon ?? 'fas fa-circle' }}"></i>
                        </div>
                        <span class="menu-name">{{ $menu->title }}</span>
                    </div>
                    <div class="td-route">
                        <code>{{ $menu->route_name ?? '-' }}</code>
                    </div>
                    <div class="td-key">
                        <code>{{ $menu->permission_key ?? '-' }}</code>
                    </div>
                    <div class="td-status">
                        <span class="status-pill {{ $menu->is_active ? 'active' : 'inactive' }}">
                            {{ $menu->is_active ? 'Active' : 'Inactive' }}
                        </span>
                    </div>
                    <div class="td-actions">
                        <button class="btn-action" onclick='editMenu(@json($menu))' title="Edit">
                            <i class="fas fa-pen"></i>
                        </button>
                        <form action="{{ route('admin.menus.destroy.menu', $menu->id) }}" method="POST" style="display:inline;" onsubmit="return confirm('Delete?');">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn-action btn-action-danger" title="Delete">
                                <i class="fas fa-trash"></i>
                            </button>
                        </form>
                    </div>
                </div>
                
                @php $childMenus = $menus->where('parent_id', $menu->id); @endphp
                @foreach($childMenus as $child)
                <div class="table-row child-row" data-id="{{ $child->id }}" data-parent-id="{{ $menu->id }}">
                    <div class="td-drag"><i class="fas fa-grip-vertical"></i></div>
                    <div class="td-title">
                        <div class="child-indicator"></div>
                        <div class="menu-icon-box small">
                            <i class="{{ $child->icon ?? 'fas fa-circle' }}"></i>
                        </div>
                        <span class="menu-name">{{ $child->title }}</span>
                    </div>
                    <div class="td-route">
                        <code>{{ $child->route_name ?? '-' }}</code>
                    </div>
                    <div class="td-key">
                        <code>{{ $child->permission_key ?? '-' }}</code>
                    </div>
                    <div class="td-status">
                        <span class="status-pill {{ $child->is_active ? 'active' : 'inactive' }}">
                            {{ $child->is_active ? 'Active' : 'Inactive' }}
                        </span>
                    </div>
                    <div class="td-actions">
                        <button class="btn-action" onclick='editMenu(@json($child))' title="Edit">
                            <i class="fas fa-pen"></i>
                        </button>
                        <form action="{{ route('admin.menus.destroy.menu', $child->id) }}" method="POST" style="display:inline;" onsubmit="return confirm('Delete?');">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn-action btn-action-danger" title="Delete">
                                <i class="fas fa-trash"></i>
                            </button>
                        </form>
                    </div>
                </div>
                @endforeach
                @empty
                <div class="table-empty">
                    <p>No menus in this group</p>
                </div>
                @endforelse
            </div>
        </div>
    </div>
    @endforeach
</div>

<!-- Group Modal -->
<div class="modal-overlay" id="groupModal">
    <div class="modal">
        <div class="modal-header">
            <h3 id="groupModalTitle">New Menu Group</h3>
            <button class="modal-close" onclick="closeGroupModal()">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <form id="groupForm" method="POST">
            @csrf
            <div id="groupMethodField"></div>
            <div class="modal-body">
                <div class="form-group">
                    <label>Title</label>
                    <input type="text" name="title" id="groupTitle" class="form-control" required placeholder="MAIN MENU">
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Slug</label>
                        <input type="text" name="slug" id="groupSlug" class="form-control" required placeholder="main-menu">
                    </div>
                    <div class="form-group">
                        <label>Sort Order</label>
                        <input type="number" name="sort_order" id="groupSortOrder" class="form-control" required min="0" value="0">
                    </div>
                </div>
                <div class="form-group">
                    <label class="toggle-label">
                        <span>Active</span>
                        <div class="toggle-switch">
                            <input type="checkbox" name="is_active" id="groupIsActive" checked>
                            <span class="toggle-slider"></span>
                        </div>
                    </label>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-cancel" onclick="closeGroupModal()">Cancel</button>
                <button type="submit" class="btn btn-primary" id="groupSubmitBtn">Create Group</button>
            </div>
        </form>
    </div>
</div>

<!-- Menu Modal -->
<div class="modal-overlay" id="menuModal">
    <div class="modal modal-lg">
        <div class="modal-header">
            <h3 id="menuModalTitle">New Menu Item</h3>
            <button class="modal-close" onclick="closeMenuModal()">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <form id="menuForm" method="POST">
            @csrf
            <div id="menuMethodField"></div>
            <div class="modal-body">
                <div class="form-section">
                    <h4>Basic Information</h4>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Menu Title</label>
                            <input type="text" name="title" id="menuTitle" class="form-control" required placeholder="Dashboard">
                        </div>
                        <div class="form-group">
                            <label>Icon Class</label>
                            <div class="icon-input">
                                <input type="text" name="icon" id="menuIcon" class="form-control" placeholder="fas fa-home" onkeyup="previewIcon(this.value)">
                                <div class="icon-preview" id="iconPreview">
                                    <i class="fas fa-home"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Group</label>
                            <select name="group_id" id="menuGroupId" class="form-control" required>
                                @foreach($menuGroups as $group)
                                    <option value="{{ $group->id }}">{{ $group->title }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Parent Menu</label>
                            <select name="parent_id" id="menuParentId" class="form-control">
                                <option value="">None (Top Level)</option>
                                @foreach($menus->whereNull('parent_id') as $menu)
                                    <option value="{{ $menu->id }}">{{ $menu->title }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                </div>
                
                <div class="form-section">
                    <h4>Navigation</h4>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Route Name</label>
                            <input type="text" name="route_name" id="menuRouteName" class="form-control" placeholder="admin.dashboard">
                        </div>
                        <div class="form-group">
                            <label>Custom URL</label>
                            <input type="text" name="url" id="menuUrl" class="form-control" placeholder="/admin/page">
                        </div>
                    </div>
                </div>
                
                <div class="form-section">
                    <h4>Settings</h4>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Permission Key</label>
                            <input type="text" name="permission_key" id="menuPermissionKey" class="form-control" placeholder="dashboard">
                        </div>
                        <div class="form-group">
                            <label>Sort Order</label>
                            <input type="number" name="sort_order" id="menuSortOrder" class="form-control" required min="0" value="0">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="toggle-label">
                            <span>Active</span>
                            <div class="toggle-switch">
                                <input type="checkbox" name="is_active" id="menuIsActive" checked>
                                <span class="toggle-slider"></span>
                            </div>
                        </label>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-cancel" onclick="closeMenuModal()">Cancel</button>
                <button type="submit" class="btn btn-primary" id="menuSubmitBtn">Create Menu</button>
            </div>
        </form>
    </div>
</div>
@endsection

@push('styles')
<style>
:root {
    --primary: #6366f1;
    --primary-dark: #4f46e5;
    --success: #10b981;
    --danger: #ef4444;
    --gray-50: #f9fafb;
    --gray-100: #f3f4f6;
    --gray-200: #e5e7eb;
    --gray-300: #d1d5db;
    --gray-400: #9ca3af;
    --gray-500: #6b7280;
    --gray-600: #4b5563;
    --gray-700: #374151;
    --gray-800: #1f2937;
    --gray-900: #111827;
    --radius: 12px;
    --radius-sm: 8px;
    --shadow: 0 1px 3px rgba(0,0,0,0.1), 0 1px 2px rgba(0,0,0,0.06);
    --shadow-lg: 0 10px 15px -3px rgba(0,0,0,0.1), 0 4px 6px -2px rgba(0,0,0,0.05);
}

.page-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 32px; }
.page-header h2 { font-size: 24px; font-weight: 700; color: var(--gray-900); margin: 0 0 4px 0; }
.page-desc { font-size: 14px; color: var(--gray-500); margin: 0; }
.header-actions { display: flex; gap: 12px; }

.btn { padding: 10px 18px; border-radius: var(--radius-sm); font-size: 14px; font-weight: 500; cursor: pointer; border: none; display: inline-flex; align-items: center; gap: 8px; transition: all 0.2s; }
.btn-primary { background: var(--primary); color: #fff; }
.btn-primary:hover { background: var(--primary-dark); }
.btn-outline { background: #fff; color: var(--gray-700); border: 1px solid var(--gray-200); }
.btn-outline:hover { background: var(--gray-50); border-color: var(--gray-300); }
.btn-cancel { background: var(--gray-100); color: var(--gray-600); }
.btn-cancel:hover { background: var(--gray-200); }

.alert { display: flex; align-items: center; gap: 12px; padding: 14px 18px; border-radius: var(--radius-sm); margin-bottom: 24px; font-size: 14px; }
.alert-success { background: #ecfdf5; color: #065f46; }
.alert-danger { background: #fef2f2; color: #991b1b; }

.menu-container { display: flex; flex-direction: column; gap: 24px; }

.menu-section { background: #fff; border-radius: var(--radius); box-shadow: var(--shadow); overflow: hidden; }

.section-header { display: flex; justify-content: space-between; align-items: center; padding: 18px 24px; background: var(--gray-50); border-bottom: 1px solid var(--gray-200); }
.section-title { display: flex; align-items: center; gap: 12px; }
.section-name { font-size: 14px; font-weight: 600; color: var(--gray-800); text-transform: uppercase; letter-spacing: 0.5px; }
.section-badge { font-size: 12px; color: var(--gray-500); background: #fff; padding: 4px 10px; border-radius: 20px; border: 1px solid var(--gray-200); }
.section-actions { display: flex; gap: 8px; }

.btn-action { width: 34px; height: 34px; border-radius: var(--radius-sm); border: 1px solid var(--gray-200); background: #fff; cursor: pointer; display: flex; align-items: center; justify-content: center; color: var(--gray-500); transition: all 0.2s; }
.btn-action:hover { background: var(--gray-50); color: var(--gray-700); border-color: var(--gray-300); }
.btn-action-danger:hover { background: #fef2f2; color: var(--danger); border-color: #fecaca; }

.menu-table { }
.table-header { display: grid; grid-template-columns: 50px 1fr 180px 150px 100px 100px; padding: 12px 24px; background: var(--gray-50); border-bottom: 1px solid var(--gray-200); font-size: 11px; font-weight: 600; color: var(--gray-500); text-transform: uppercase; letter-spacing: 0.5px; }
.table-body { min-height: 60px; }
.table-row { display: grid; grid-template-columns: 50px 1fr 180px 150px 100px 100px; padding: 14px 24px; border-bottom: 1px solid var(--gray-100); align-items: center; transition: all 0.2s; background: #fff; }
.table-row:hover { background: var(--gray-50); }
.table-row:last-child { border-bottom: none; }

.child-row { background: var(--gray-50); }
.child-row:hover { background: var(--gray-100); }
.child-row .td-title { padding-left: 24px; }
.child-indicator { width: 16px; height: 16px; border-left: 2px solid var(--gray-300); border-bottom: 2px solid var(--gray-300); border-radius: 0 0 0 4px; margin-right: 12px; }

.td-drag { color: var(--gray-300); cursor: grab; font-size: 16px; }
.td-drag:active { cursor: grabbing; }
.td-drag:hover { color: var(--gray-500); }

.td-title { display: flex; align-items: center; gap: 12px; }
.menu-icon-box { width: 38px; height: 38px; background: linear-gradient(135deg, var(--primary) 0%, #8b5cf6 100%); border-radius: var(--radius-sm); display: flex; align-items: center; justify-content: center; color: #fff; font-size: 14px; flex-shrink: 0; }
.menu-icon-box.small { width: 32px; height: 32px; font-size: 12px; }
.menu-name { font-size: 14px; font-weight: 500; color: var(--gray-800); }

.td-route code, .td-key code { font-size: 12px; color: var(--gray-600); background: var(--gray-100); padding: 4px 8px; border-radius: 4px; display: inline-block; }

.status-pill { font-size: 12px; font-weight: 500; padding: 4px 12px; border-radius: 20px; }
.status-pill.active { background: #ecfdf5; color: #065f46; }
.status-pill.inactive { background: #fef2f2; color: #991b1b; }

.td-actions { display: flex; gap: 6px; }

.table-empty { padding: 48px 24px; text-align: center; color: var(--gray-400); }
.table-empty p { margin: 0; }

/* Modal Styles */
.modal-overlay { display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(17, 24, 39, 0.7); z-index: 9999; align-items: center; justify-content: center; backdrop-filter: blur(4px); }
.modal-overlay.show { display: flex; }

.modal { background: #fff; border-radius: var(--radius); width: 100%; max-width: 480px; max-height: 90vh; overflow: hidden; box-shadow: var(--shadow-lg); animation: modalIn 0.2s ease; }
.modal.modal-lg { max-width: 640px; }

@keyframes modalIn {
    from { opacity: 0; transform: scale(0.95) translateY(-10px); }
    to { opacity: 1; transform: scale(1) translateY(0); }
}

.modal-header { display: flex; justify-content: space-between; align-items: center; padding: 20px 24px; border-bottom: 1px solid var(--gray-200); }
.modal-header h3 { font-size: 18px; font-weight: 600; color: var(--gray-900); margin: 0; }
.modal-close { width: 36px; height: 36px; border-radius: var(--radius-sm); border: none; background: var(--gray-100); cursor: pointer; display: flex; align-items: center; justify-content: center; color: var(--gray-500); transition: all 0.2s; }
.modal-close:hover { background: var(--gray-200); color: var(--gray-700); }

.modal-body { padding: 24px; max-height: calc(90vh - 160px); overflow-y: auto; }
.modal-footer { display: flex; justify-content: flex-end; gap: 12px; padding: 16px 24px; background: var(--gray-50); border-top: 1px solid var(--gray-200); }

.form-section { margin-bottom: 24px; padding-bottom: 24px; border-bottom: 1px solid var(--gray-100); }
.form-section:last-child { margin-bottom: 0; padding-bottom: 0; border-bottom: none; }
.form-section h4 { font-size: 13px; font-weight: 600; color: var(--gray-500); text-transform: uppercase; letter-spacing: 0.5px; margin: 0 0 16px 0; }

.form-row { display: grid; grid-template-columns: repeat(2, 1fr); gap: 16px; }
.form-group { margin-bottom: 16px; }
.form-group:last-child { margin-bottom: 0; }
.form-group label { display: block; font-size: 13px; font-weight: 500; color: var(--gray-700); margin-bottom: 6px; }

.form-control { width: 100%; padding: 10px 14px; border: 1px solid var(--gray-200); border-radius: var(--radius-sm); font-size: 14px; color: var(--gray-800); transition: all 0.2s; background: #fff; }
.form-control:focus { outline: none; border-color: var(--primary); box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.1); }
.form-control::placeholder { color: var(--gray-400); }

.icon-input { display: flex; gap: 10px; }
.icon-input .form-control { flex: 1; }
.icon-preview { width: 44px; height: 44px; background: var(--gray-100); border-radius: var(--radius-sm); display: flex; align-items: center; justify-content: center; color: var(--gray-600); font-size: 18px; flex-shrink: 0; }

.toggle-label { display: flex; align-items: center; justify-content: space-between; cursor: pointer; }
.toggle-label > span { font-size: 14px; color: var(--gray-700); }

.toggle-switch { position: relative; width: 48px; height: 26px; }
.toggle-switch input { opacity: 0; width: 0; height: 0; }
.toggle-slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background: var(--gray-300); border-radius: 26px; transition: 0.3s; }
.toggle-slider:before { position: absolute; content: ""; height: 20px; width: 20px; left: 3px; bottom: 3px; background: #fff; border-radius: 50%; transition: 0.3s; box-shadow: 0 1px 3px rgba(0,0,0,0.2); }
.toggle-switch input:checked + .toggle-slider { background: var(--primary); }
.toggle-switch input:checked + .toggle-slider:before { transform: translateX(22px); }

/* Toast Notification */
.toast {
    position: fixed;
    bottom: 24px;
    right: 24px;
    padding: 14px 20px;
    background: var(--gray-800);
    color: #fff;
    border-radius: var(--radius-sm);
    font-size: 14px;
    font-weight: 500;
    display: flex;
    align-items: center;
    gap: 10px;
    z-index: 99999;
    box-shadow: var(--shadow-lg);
    animation: toastIn 0.3s ease;
}
.toast-success { background: var(--success); }
.toast-error { background: var(--danger); }
.toast-info { background: var(--primary); }
.toast-hide { opacity: 0; transform: translateY(10px); transition: all 0.3s; }

@keyframes toastIn {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
}

/* Sortable styles */
.sortable-ghost { opacity: 0.4; background: #eef2ff !important; }
.sortable-drag { background: #fff !important; box-shadow: var(--shadow-lg); border-radius: var(--radius-sm); }
.sortable-chosen { background: #fafafa; }
</style>
@endpush

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.0/Sortable.min.js"></script>
<script>
// Initialize Sortable for each group
document.querySelectorAll('[id^="sortable-"]').forEach(function(el) {
    new Sortable(el, {
        animation: 150,
        handle: '.td-drag',
        ghostClass: 'sortable-ghost',
        chosenClass: 'sortable-chosen',
        dragClass: 'sortable-drag',
        onEnd: function(evt) {
            saveOrder(evt.to);
        }
    });
});

// Save order via AJAX
function saveOrder(container) {
    const rows = container.querySelectorAll('.table-row');
    const items = [];
    let currentParentId = null;
    
    rows.forEach(function(row, index) {
        if (row.classList.contains('parent-row')) {
            currentParentId = row.dataset.id;
            items.push({
                id: row.dataset.id,
                parent_id: null
            });
        } else {
            items.push({
                id: row.dataset.id,
                parent_id: currentParentId
            });
        }
    });
    
    showToast('Saving...', 'info');
    
    fetch('{{ route("admin.menus.update-order") }}', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': '{{ csrf_token() }}'
        },
        body: JSON.stringify({ items: items })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showToast('Order saved!', 'success');
        } else {
            showToast('Error saving order', 'error');
        }
    })
    .catch(error => {
        showToast('Error saving order', 'error');
        console.error(error);
    });
}

function showToast(message, type) {
    const existingToast = document.querySelector('.toast');
    if (existingToast) existingToast.remove();
    
    const iconMap = {
        success: 'check-circle',
        error: 'exclamation-circle',
        info: 'spinner fa-spin'
    };
    
    const toast = document.createElement('div');
    toast.className = 'toast toast-' + type;
    toast.innerHTML = '<i class="fas fa-' + iconMap[type] + '"></i> ' + message;
    document.body.appendChild(toast);
    
    if (type !== 'info') {
        setTimeout(function() {
            toast.classList.add('toast-hide');
            setTimeout(function() {
                toast.remove();
            }, 300);
        }, 2000);
    }
}

function previewIcon(value) {
    document.getElementById('iconPreview').innerHTML = '<i class="' + (value || 'fas fa-home') + '"></i>';
}

function openGroupModal() {
    document.getElementById('groupModalTitle').textContent = 'New Menu Group';
    document.getElementById('groupForm').action = '{{ route("admin.menus.groups.store") }}';
    document.getElementById('groupMethodField').innerHTML = '';
    document.getElementById('groupTitle').value = '';
    document.getElementById('groupSlug').value = '';
    document.getElementById('groupSortOrder').value = '0';
    document.getElementById('groupIsActive').checked = true;
    document.getElementById('groupSubmitBtn').textContent = 'Create Group';
    document.getElementById('groupModal').classList.add('show');
}

function editGroup(id, title, slug, sortOrder, isActive) {
    document.getElementById('groupModalTitle').textContent = 'Edit Menu Group';
    document.getElementById('groupForm').action = '/menus/groups/' + id;
    document.getElementById('groupMethodField').innerHTML = '@method("PUT")';
    document.getElementById('groupTitle').value = title;
    document.getElementById('groupSlug').value = slug;
    document.getElementById('groupSortOrder').value = sortOrder;
    document.getElementById('groupIsActive').checked = isActive == 1;
    document.getElementById('groupSubmitBtn').textContent = 'Update Group';
    document.getElementById('groupModal').classList.add('show');
}

function closeGroupModal() {
    document.getElementById('groupModal').classList.remove('show');
}

function openMenuModal() {
    document.getElementById('menuModalTitle').textContent = 'New Menu Item';
    document.getElementById('menuForm').action = '{{ route("admin.menus.store") }}';
    document.getElementById('menuMethodField').innerHTML = '';
    document.getElementById('menuGroupId').value = '';
    document.getElementById('menuParentId').value = '';
    document.getElementById('menuTitle').value = '';
    document.getElementById('menuIcon').value = '';
    document.getElementById('menuRouteName').value = '';
    document.getElementById('menuUrl').value = '';
    document.getElementById('menuPermissionKey').value = '';
    document.getElementById('menuSortOrder').value = '0';
    document.getElementById('menuIsActive').checked = true;
    document.getElementById('menuSubmitBtn').textContent = 'Create Menu';
    previewIcon('');
    document.getElementById('menuModal').classList.add('show');
}

function editMenu(menu) {
    document.getElementById('menuModalTitle').textContent = 'Edit Menu Item';
    document.getElementById('menuForm').action = '/menus/' + menu.id;
    document.getElementById('menuMethodField').innerHTML = '@method("PUT")';
    document.getElementById('menuGroupId').value = menu.group_id;
    document.getElementById('menuParentId').value = menu.parent_id || '';
    document.getElementById('menuTitle').value = menu.title;
    document.getElementById('menuIcon').value = menu.icon || '';
    document.getElementById('menuRouteName').value = menu.route_name || '';
    document.getElementById('menuUrl').value = menu.url || '';
    document.getElementById('menuPermissionKey').value = menu.permission_key || '';
    document.getElementById('menuSortOrder').value = menu.sort_order;
    document.getElementById('menuIsActive').checked = menu.is_active == 1;
    document.getElementById('menuSubmitBtn').textContent = 'Update Menu';
    previewIcon(menu.icon || '');
    document.getElementById('menuModal').classList.add('show');
}

function closeMenuModal() {
    document.getElementById('menuModal').classList.remove('show');
}

document.getElementById('groupModal').addEventListener('click', function(e) {
    if (e.target === this) closeGroupModal();
});
document.getElementById('menuModal').addEventListener('click', function(e) {
    if (e.target === this) closeMenuModal();
});

document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closeGroupModal();
        closeMenuModal();
    }
});
</script>
@endpush