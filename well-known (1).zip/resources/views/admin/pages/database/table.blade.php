@extends('admin.layouts.app')
@section('title', $table)
@push('styles')
<style>
.page-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;flex-wrap:wrap;gap:12px}
.page-title{font-size:22px;font-weight:700;color:#1e293b}
.breadcrumb{font-size:13px;color:#64748b;margin-bottom:4px}.breadcrumb a{color:#4f46e5;text-decoration:none}
.card{background:#fff;border-radius:10px;border:1px solid #e2e8f0;margin-bottom:20px;overflow:hidden}
.card-header{padding:14px 20px;border-bottom:1px solid #e2e8f0;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px}
.card-title{font-size:15px;font-weight:600;color:#1e293b}
.tabs{display:flex;gap:0;border-bottom:2px solid #e2e8f0;padding:0 20px}
.tab{padding:10px 16px;font-size:13px;font-weight:500;color:#64748b;cursor:pointer;border-bottom:2px solid transparent;margin-bottom:-2px;text-decoration:none}
.tab:hover{color:#374151}.tab.active{color:#4f46e5;border-bottom-color:#4f46e5}
table{width:100%;border-collapse:collapse}
th{text-align:left;padding:8px 12px;font-size:11px;font-weight:600;color:#64748b;text-transform:uppercase;background:#f8fafc;border-bottom:1px solid #e2e8f0;white-space:nowrap}
td{padding:8px 12px;font-size:12px;color:#374151;border-bottom:1px solid #f1f5f9;max-width:250px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
tr:hover td{background:#fafbfc}
.data-table-wrap{overflow-x:auto}
.info-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;padding:16px 20px}
.info-item label{font-size:11px;font-weight:600;color:#94a3b8;text-transform:uppercase;display:block;margin-bottom:2px}.info-item span{font-size:13px;font-weight:500;color:#1e293b}
.badge-pk{background:#fef3c7;color:#92400e;padding:1px 6px;border-radius:3px;font-size:10px;font-weight:600}
.badge-null{background:#f1f5f9;color:#94a3b8;padding:1px 6px;border-radius:3px;font-size:10px}
.badge-ai{background:#eff6ff;color:#3b82f6;padding:1px 6px;border-radius:3px;font-size:10px}
.btn-xs{padding:3px 8px;font-size:11px;border-radius:4px;cursor:pointer;border:none;text-decoration:none;display:inline-flex;align-items:center;gap:4px}
.btn-red{background:#fef2f2;color:#ef4444}.btn-blue{background:#eff6ff;color:#3b82f6}
.btn-outline{background:transparent;border:1px solid #d1d5db;color:#374151;padding:6px 14px;border-radius:6px;font-size:13px;cursor:pointer;text-decoration:none;display:inline-flex;align-items:center;gap:6px}
.pager{padding:12px 20px;display:flex;justify-content:space-between;align-items:center;font-size:13px;color:#64748b;border-top:1px solid #e2e8f0}
.pager a{color:#4f46e5;text-decoration:none;padding:4px 10px;border:1px solid #e2e8f0;border-radius:4px;font-size:12px}
.pager a:hover{background:#f1f5f9}
.pager .current{background:#4f46e5;color:#fff;border-color:#4f46e5;padding:4px 10px;border-radius:4px;font-size:12px}
.sql-box{background:#0f172a;color:#e2e8f0;padding:16px 20px;font-family:'Courier New',monospace;font-size:12px;white-space:pre-wrap;max-height:300px;overflow-y:auto;border-radius:0 0 10px 10px}
td.null-val{color:#d1d5db;font-style:italic}
.nav-pills{display:flex;gap:6px;flex-wrap:wrap}
.nav-pill{padding:6px 14px;border-radius:6px;font-size:13px;text-decoration:none;color:#64748b;border:1px solid #e2e8f0;display:inline-flex;align-items:center;gap:6px}
.nav-pill:hover{background:#f1f5f9;color:#374151}
</style>
@endpush
@section('content')
<div class="page-header">
<div>
<div class="breadcrumb"><a href="{{ route('admin.database.index') }}">Database</a> &rsaquo; {{ $table }}</div>
<h1 class="page-title">{{ $table }}</h1>
</div>
<div class="nav-pills">
<a href="{{ route('admin.database.index') }}" class="nav-pill"><i class="fas fa-arrow-left"></i> Tables</a>
<a href="{{ route('admin.database.query') }}?sql=SELECT * FROM `{{ $table }}` LIMIT 100" class="nav-pill"><i class="fas fa-terminal"></i> Query</a>
<form method="POST" action="{{ route('admin.database.truncate', $table) }}" style="display:inline" onsubmit="return confirm('TRUNCATE all data from `{{ $table }}`?')">@csrf<button class="nav-pill" style="cursor:pointer"><i class="fas fa-eraser"></i> Truncate</button></form>
</div>
</div>

{{-- Table Info --}}
@if($tableInfo)
<div class="card">
<div class="info-grid">
<div class="info-item"><label>Engine</label><span>{{ $tableInfo->Engine }}</span></div>
<div class="info-item"><label>Rows</label><span>{{ number_format($totalRows) }}</span></div>
<div class="info-item"><label>Size</label><span>{{ number_format((($tableInfo->Data_length??0)+($tableInfo->Index_length??0))/1024,1) }} KB</span></div>
<div class="info-item"><label>Collation</label><span>{{ $tableInfo->Collation }}</span></div>
<div class="info-item"><label>Auto Increment</label><span>{{ $tableInfo->Auto_increment ?? '--' }}</span></div>
<div class="info-item"><label>Created</label><span>{{ $tableInfo->Create_time }}</span></div>
</div>
</div>
@endif

{{-- Tabs --}}
<div class="card">
<div class="tabs">
<a class="tab active" onclick="showTab('data')">Data ({{ number_format($totalRows) }})</a>
<a class="tab" onclick="showTab('structure')">Structure ({{ count($columns) }})</a>
<a class="tab" onclick="showTab('indexes')">Indexes ({{ count($indexes) }})</a>
<a class="tab" onclick="showTab('sql')">SQL</a>
</div>

{{-- DATA TAB --}}
<div id="tab-data">
<div class="data-table-wrap">
@if(empty($rows))
<div style="text-align:center;padding:40px;color:#94a3b8"><i class="fas fa-inbox" style="font-size:30px;display:block;margin-bottom:8px"></i>No data</div>
@else
<table>
<thead><tr><th>#</th>
@foreach(array_keys((array)$rows[0]) as $col)<th>{{ $col }}</th>@endforeach
<th>Actions</th></tr></thead>
<tbody>
@foreach($rows as $i => $row)
@php $rowArr = (array)$row; $pk = array_key_first($rowArr); $pkVal = $rowArr[$pk]; @endphp
<tr>
<td style="color:#94a3b8">{{ $offset + $i + 1 }}</td>
@foreach($rowArr as $val)
<td @if(is_null($val)) class="null-val" @endif>{{ is_null($val) ? 'NULL' : \Illuminate\Support\Str::limit((string)$val, 80) }}</td>
@endforeach
<td><form method="POST" action="{{ route('admin.database.delete-row', $table) }}" style="display:inline" onsubmit="return confirm('Delete this row?')">@csrf <input type="hidden" name="where" value="`{{ $pk }}`='{{ addslashes($pkVal) }}'"><input type="hidden" name="page" value="{{ $page }}"><button class="btn-xs btn-red"><i class="fas fa-trash"></i></button></form></td>
</tr>
@endforeach
</tbody>
</table>
@endif
</div>
@if($totalPages > 1)
<div class="pager">
<span>Showing {{ $offset+1 }}-{{ min($offset+$perPage,$totalRows) }} of {{ number_format($totalRows) }}</span>
<div style="display:flex;gap:4px">
@if($page > 1)<a href="?page={{ $page-1 }}">&laquo;</a>@endif
@for($p = max(1,$page-3); $p <= min($totalPages,$page+3); $p++)
@if($p==$page)<span class="current">{{ $p }}</span>@else<a href="?page={{ $p }}">{{ $p }}</a>@endif
@endfor
@if($page < $totalPages)<a href="?page={{ $page+1 }}">&raquo;</a>@endif
</div>
</div>
@endif
</div>

{{-- STRUCTURE TAB --}}
<div id="tab-structure" style="display:none">
<table>
<thead><tr><th>Column</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th><th>Collation</th></tr></thead>
<tbody>
@foreach($columns as $col)
<tr>
<td style="font-weight:600">{{ $col->Field }}</td>
<td style="font-family:monospace;font-size:12px;color:#64748b">{{ $col->Type }}</td>
<td>@if($col->Null==='YES')<span class="badge-null">NULL</span>@else NO @endif</td>
<td>@if($col->Key==='PRI')<span class="badge-pk">PK</span>@elseif($col->Key==='UNI')UNI @elseif($col->Key==='MUL')IDX @endif</td>
<td style="color:#94a3b8">{{ $col->Default ?? 'none' }}</td>
<td>@if(str_contains($col->Extra,'auto_increment'))<span class="badge-ai">AI</span>@else {{ $col->Extra }} @endif</td>
<td style="font-size:11px;color:#94a3b8">{{ $col->Collation }}</td>
</tr>
@endforeach
</tbody>
</table>
</div>

{{-- INDEXES TAB --}}
<div id="tab-indexes" style="display:none">
<table>
<thead><tr><th>Name</th><th>Column</th><th>Unique</th><th>Type</th></tr></thead>
<tbody>
@foreach($indexes as $idx)
<tr><td style="font-weight:500">{{ $idx->Key_name }}</td><td>{{ $idx->Column_name }}</td><td>{{ $idx->Non_unique ? 'No' : 'Yes' }}</td><td>{{ $idx->Index_type }}</td></tr>
@endforeach
</tbody>
</table>
</div>

{{-- SQL TAB --}}
<div id="tab-sql" style="display:none">
<div class="sql-box">{{ $createSql }}</div>
</div>
</div>

@if(session('success'))<div id="toast" style="position:fixed;bottom:24px;right:24px;background:#22c55e;color:#fff;padding:12px 20px;border-radius:8px;font-size:13px;z-index:10000"><i class="fas fa-check-circle"></i> {{ session('success') }}</div><script>setTimeout(()=>document.getElementById('toast')?.remove(),4000)</script>@endif
@endsection
@push('scripts')
<script>
function showTab(name){
document.querySelectorAll('[id^="tab-"]').forEach(t=>t.style.display='none');
document.querySelectorAll('.tab').forEach(t=>t.classList.remove('active'));
document.getElementById('tab-'+name).style.display='block';
event.target.classList.add('active');
}
</script>
@endpush
