@extends('admin.layouts.app')
@section('title', 'Database Manager')
@push('styles')
<style>
.page-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;flex-wrap:wrap;gap:12px}
.page-title{font-size:22px;font-weight:700;color:#1e293b}
.page-sub{font-size:13px;color:#64748b}
.stats-row{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;margin-bottom:20px}
.stat-card{background:#fff;border-radius:10px;padding:16px;border:1px solid #e2e8f0;display:flex;align-items:center;gap:14px}
.stat-icon{width:42px;height:42px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:18px}
.stat-icon.blue{background:#eff6ff;color:#3b82f6}.stat-icon.green{background:#f0fdf4;color:#22c55e}.stat-icon.purple{background:#faf5ff;color:#a855f7}
.stat-val{font-size:20px;font-weight:700;color:#1e293b}.stat-label{font-size:12px;color:#64748b}
.card{background:#fff;border-radius:10px;border:1px solid #e2e8f0;margin-bottom:20px;overflow:hidden}
.card-header{padding:14px 20px;border-bottom:1px solid #e2e8f0;display:flex;justify-content:space-between;align-items:center}
.card-title{font-size:15px;font-weight:600;color:#1e293b}
.nav-pills{display:flex;gap:6px;flex-wrap:wrap}
.nav-pill{padding:6px 14px;border-radius:6px;font-size:13px;text-decoration:none;color:#64748b;border:1px solid #e2e8f0;display:inline-flex;align-items:center;gap:6px}
.nav-pill:hover{background:#f1f5f9;color:#374151}.nav-pill.active{background:#4f46e5;color:#fff;border-color:#4f46e5}
table{width:100%;border-collapse:collapse}
th{text-align:left;padding:10px 16px;font-size:11px;font-weight:600;color:#64748b;text-transform:uppercase;letter-spacing:.5px;background:#f8fafc;border-bottom:1px solid #e2e8f0}
td{padding:10px 16px;font-size:13px;color:#374151;border-bottom:1px solid #f1f5f9}
tr:hover td{background:#fafbfc}
.tname{font-weight:600;color:#4f46e5;text-decoration:none}.tname:hover{text-decoration:underline}
.btn-xs{padding:3px 8px;font-size:11px;border-radius:4px;cursor:pointer;border:none;text-decoration:none;display:inline-flex;align-items:center;gap:4px}
.btn-blue{background:#eff6ff;color:#3b82f6}.btn-red{background:#fef2f2;color:#ef4444}
.btn-primary{background:#4f46e5;color:#fff;border:none;padding:8px 16px;border-radius:6px;font-size:13px;cursor:pointer;text-decoration:none;display:inline-flex;align-items:center;gap:6px}
.search-box{padding:8px 12px;border:1px solid #d1d5db;border-radius:6px;font-size:13px;width:250px}
.search-box:focus{outline:none;border-color:#4f46e5}
</style>
@endpush
@section('content')
<div class="page-header">
<div>
<h1 class="page-title"><i class="fas fa-database" style="color:#4f46e5"></i> Database Manager</h1>
<p class="page-sub">Database: <strong>{{ $dbName }}</strong></p>
</div>
<div class="nav-pills">
<a href="{{ route('admin.database.index') }}" class="nav-pill active"><i class="fas fa-table"></i> Tables</a>
<a href="{{ route('admin.database.query') }}" class="nav-pill"><i class="fas fa-terminal"></i> SQL Query</a>
<a href="{{ route('admin.database.export') }}" class="nav-pill"><i class="fas fa-download"></i> Export</a>
<a href="{{ route('admin.database.import') }}" class="nav-pill"><i class="fas fa-upload"></i> Import</a>
</div>
</div>

<div class="stats-row">
<div class="stat-card"><div class="stat-icon blue"><i class="fas fa-table"></i></div><div><div class="stat-val">{{ count($tableList) }}</div><div class="stat-label">Tables</div></div></div>
<div class="stat-card"><div class="stat-icon green"><i class="fas fa-hdd"></i></div><div><div class="stat-val">{{ $totalSize >= 1048576 ? number_format($totalSize/1048576,1).' MB' : number_format($totalSize/1024,1).' KB' }}</div><div class="stat-label">Database Size</div></div></div>
<div class="stat-card"><div class="stat-icon purple"><i class="fas fa-server"></i></div><div><div class="stat-val">{{ config('database.connections.mysql.host') }}</div><div class="stat-label">Server</div></div></div>
</div>

<div class="card">
<div class="card-header">
<span class="card-title">All Tables</span>
<input type="text" class="search-box" id="tableSearch" placeholder="Search tables..." onkeyup="filterTables()">
</div>
<table id="tableList">
<thead><tr><th><input type="checkbox" id="checkAll" onclick="toggleAll()"></th><th>Table Name</th><th>Engine</th><th>Rows</th><th>Size</th><th>Collation</th><th>Actions</th></tr></thead>
<tbody>
@foreach($tableList as $t)
<tr>
<td><input type="checkbox" class="tbl-check" value="{{ $t['name'] }}"></td>
<td><a href="{{ route('admin.database.table', $t['name']) }}" class="tname">{{ $t['name'] }}</a></td>
<td>{{ $t['engine'] }}</td>
<td>{{ number_format($t['rows']) }}</td>
<td>{{ $t['size'] >= 1048576 ? number_format($t['size']/1048576,2).' MB' : number_format($t['size']/1024,1).' KB' }}</td>
<td style="font-size:11px;color:#94a3b8">{{ $t['collation'] }}</td>
<td>
<a href="{{ route('admin.database.table', $t['name']) }}" class="btn-xs btn-blue"><i class="fas fa-eye"></i> View</a>
<form method="POST" action="{{ route('admin.database.truncate', $t['name']) }}" style="display:inline" onsubmit="return confirm('TRUNCATE `{{ $t['name'] }}`? All data will be deleted!')">@csrf <button class="btn-xs btn-red"><i class="fas fa-eraser"></i></button></form>
<form method="POST" action="{{ route('admin.database.drop', $t['name']) }}" style="display:inline" onsubmit="return confirm('DROP `{{ $t['name'] }}`? This cannot be undone!')">@csrf @method('DELETE')<button class="btn-xs btn-red"><i class="fas fa-trash"></i></button></form>
</td>
</tr>
@endforeach
</tbody>
</table>
</div>

@if(session('success'))<div id="toast" style="position:fixed;bottom:24px;right:24px;background:#22c55e;color:#fff;padding:12px 20px;border-radius:8px;font-size:13px;z-index:10000"><i class="fas fa-check-circle"></i> {{ session('success') }}</div><script>setTimeout(()=>document.getElementById('toast')?.remove(),4000)</script>@endif
@endsection
@push('scripts')
<script>
function filterTables(){const v=document.getElementById('tableSearch').value.toLowerCase();document.querySelectorAll('#tableList tbody tr').forEach(r=>{r.style.display=r.textContent.toLowerCase().includes(v)?'':'none'})}
function toggleAll(){const c=document.getElementById('checkAll').checked;document.querySelectorAll('.tbl-check').forEach(cb=>cb.checked=c)}
</script>
@endpush
