@extends('admin.layouts.app')
@section('title', 'Restore Backup')
@push('styles')
<style>
.page-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:20px}.page-title{font-size:22px;font-weight:700;color:#1e293b}.breadcrumb{font-size:13px;color:#64748b;margin-bottom:4px}.breadcrumb a{color:#4f46e5;text-decoration:none}
.section-card{background:#fff;border-radius:10px;border:1px solid #e2e8f0;margin-bottom:20px}
.section-header{padding:16px 20px;border-bottom:1px solid #e2e8f0}
.section-title{font-size:16px;font-weight:600;color:#1e293b}
.restore-info{padding:20px}
.info-row{display:flex;justify-content:space-between;padding:10px 0;border-bottom:1px solid #f1f5f9;font-size:14px}
.info-row:last-child{border:none}
.info-label{color:#64748b;font-weight:500}
.info-value{color:#1e293b;font-weight:500;font-family:monospace}
.warning-box{background:#fffbeb;border:1px solid #fde68a;border-radius:10px;padding:16px 20px;margin-bottom:20px}
.warning-box h4{color:#92400e;font-size:14px;margin-bottom:8px;display:flex;align-items:center;gap:8px}
.warning-box p{color:#a16207;font-size:13px;line-height:1.6;margin:0}
.warning-box ul{color:#a16207;font-size:13px;line-height:1.8;margin:8px 0 0 20px;padding:0}
.danger-box{background:#fef2f2;border:1px solid #fecaca;border-radius:10px;padding:16px 20px;margin-bottom:20px}
.danger-box h4{color:#991b1b;font-size:14px;margin-bottom:8px;display:flex;align-items:center;gap:8px}
.danger-box p{color:#b91c1c;font-size:13px;line-height:1.6;margin:0}
.btn-primary{background:#4f46e5;color:#fff;border:none;padding:10px 20px;border-radius:6px;font-size:14px;cursor:pointer;display:inline-flex;align-items:center;gap:8px}
.btn-primary:hover{background:#4338ca}
.btn-danger{background:#ef4444;color:#fff;border:none;padding:10px 20px;border-radius:6px;font-size:14px;cursor:pointer;display:inline-flex;align-items:center;gap:8px}
.btn-danger:hover{background:#dc2626}
.btn-outline{background:transparent;border:1px solid #d1d5db;color:#374151;padding:10px 20px;border-radius:6px;font-size:14px;cursor:pointer;text-decoration:none;display:inline-flex;align-items:center;gap:8px}
.confirm-section{padding:20px;display:flex;flex-direction:column;align-items:center;gap:16px}
.confirm-checkbox{display:flex;align-items:center;gap:10px;font-size:14px;color:#374151;cursor:pointer}
.confirm-checkbox input{width:18px;height:18px}
.tag{display:inline-block;padding:2px 8px;border-radius:4px;font-size:11px;background:#f1f5f9;color:#475569;margin:2px;font-family:monospace}
</style>
@endpush
@section('content')
<div class="page-header">
<div>
<div class="breadcrumb"><a href="{{ route('admin.backup.index') }}">Backup</a> &rsaquo; <a href="{{ route('admin.backup.history') }}">History</a> &rsaquo; Restore</div>
<h1 class="page-title"><i class="fas fa-undo" style="color:#a855f7"></i> Restore Backup</h1>
</div>
<a href="{{ route('admin.backup.history') }}" class="btn-outline"><i class="fas fa-arrow-left"></i> Back</a>
</div>

{{-- Warning --}}
<div class="warning-box">
<h4><i class="fas fa-exclamation-triangle"></i> Important: Read Before Restoring</h4>
<ul>
<li>Restoring will <strong>overwrite existing files</strong> with the backup copies</li>
<li>If database restore is included, it will <strong>replace all current data</strong></li>
<li>It is recommended to create a new backup before restoring</li>
<li>This action cannot be easily undone</li>
</ul>
</div>

{{-- Backup Details --}}
<div class="section-card">
<div class="section-header"><span class="section-title">Backup Snapshot Details</span></div>
<div class="restore-info">
<div class="info-row"><span class="info-label">Folder</span><span class="info-value">{{ $run->folder_name }}</span></div>
<div class="info-row"><span class="info-label">Created</span><span class="info-value">{{ $run->created_at->format('d M Y H:i:s') }}</span></div>
<div class="info-row"><span class="info-label">Job</span><span class="info-value">{{ $run->job ? $run->job->name : 'Manual Backup' }}</span></div>
<div class="info-row"><span class="info-label">Total Files</span><span class="info-value">{{ number_format($run->total_files) }}</span></div>
<div class="info-row"><span class="info-label">Total Size</span><span class="info-value">{{ $run->formatted_size }}</span></div>
<div class="info-row"><span class="info-label">Database Included</span><span class="info-value">{{ $run->include_database ? 'Yes' : 'No' }}</span></div>
<div class="info-row">
<span class="info-label">Include Paths</span>
<span>@foreach(($run->include_paths ?? []) as $p)<span class="tag">{{ $p }}</span>@endforeach @if(empty($run->include_paths))<span style="color:#94a3b8;font-size:12px">Default</span>@endif</span>
</div>
@if($metadata)
<div class="info-row"><span class="info-label">Laravel Version</span><span class="info-value">{{ $metadata['laravel_version'] ?? '--' }}</span></div>
<div class="info-row"><span class="info-label">PHP Version</span><span class="info-value">{{ $metadata['php_version'] ?? '--' }}</span></div>
@endif
</div>
</div>

{{-- Database Warning --}}
@if($run->include_database)
<div class="danger-box">
<h4><i class="fas fa-database"></i> Database Restore Warning</h4>
<p>This backup includes a database dump. Restoring it will <strong>DROP and recreate all tables</strong> with the backup data. Any data entered after this backup was created will be lost permanently.</p>
</div>
@endif

{{-- Confirm & Restore --}}
<div class="section-card">
<div class="confirm-section">
<label class="confirm-checkbox">
<input type="checkbox" id="confirmCheck" onchange="toggleRestoreBtn()">
I understand this will overwrite existing files{{ $run->include_database ? ' and database' : '' }}. I want to proceed.
</label>
<div style="display:flex;gap:12px">
<a href="{{ route('admin.backup.history') }}" class="btn-outline"><i class="fas fa-times"></i> Cancel</a>
<form method="POST" action="{{ route('admin.backup.restore.execute', $run->id) }}" id="restoreForm">
@csrf
<button type="submit" class="btn-danger" id="restoreBtn" disabled onclick="return confirm('FINAL CONFIRMATION: Are you absolutely sure you want to restore from {{ $run->folder_name }}?')">
<i class="fas fa-undo"></i> Restore Now
</button>
</form>
</div>
</div>
</div>
@endsection
@push('scripts')
<script>
function toggleRestoreBtn(){
document.getElementById('restoreBtn').disabled=!document.getElementById('confirmCheck').checked;
}
</script>
@endpush
