#!/bin/bash
# Run this script from your project root (e.g. /home/mybusiness/office.mybusiness.com.my)
# It creates symlinks so the browser can access vendor assets

# Create public/vendor directory if not exists
mkdir -p public/vendor

# Symlink file-manager assets
if [ -d "vendor/alexusmai/laravel-file-manager/resources/assets" ]; then
    ln -sfn ../../vendor/alexusmai/laravel-file-manager/resources/assets public/vendor/file-manager
    echo "✓ file-manager symlinked"
elif [ -d "vendor/file-manager" ]; then
    ln -sfn ../../vendor/file-manager public/vendor/file-manager
    echo "✓ file-manager symlinked (from root vendor/file-manager)"
else
    echo "✗ file-manager assets not found"
fi

# Symlink monaco-editor
if [ -d "vendor/monaco-editor" ]; then
    ln -sfn ../../vendor/monaco-editor public/vendor/monaco-editor
    echo "✓ monaco-editor symlinked"
else
    echo "✗ monaco-editor not found at vendor/monaco-editor"
fi

echo ""
echo "Done. Check public/vendor/ :"
ls -la public/vendor/
