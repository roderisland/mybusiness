<?php $__env->startSection("title", "Admin List"); ?>
<?php $__env->startSection("content"); ?>
<div class="card"><div class="card-header"><h3>Admin Users</h3></div><div class="card-body"><p>Content here.</p></div></div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush("styles"); ?>
<style>.card{background:#fff;border-radius:12px;box-shadow:0 1px 3px rgba(0,0,0,0.1);}.card-header{padding:18px 20px;border-bottom:1px solid #e2e8f0;}.card-header h3{font-size:16px;font-weight:600;}.card-body{padding:20px;}</style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make("admin.layouts.app", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/mybusiness/office.mybusiness.com.my/resources/views/admin/pages/settings/security.blade.php ENDPATH**/ ?>