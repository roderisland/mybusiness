<?php $__env->startSection('title', 'SQL Query'); ?>
<?php $__env->startPush('styles'); ?>
<style>
.page-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;flex-wrap:wrap;gap:12px}
.page-title{font-size:22px;font-weight:700;color:#1e293b}
.nav-pills{display:flex;gap:6px;flex-wrap:wrap}
.nav-pill{padding:6px 14px;border-radius:6px;font-size:13px;text-decoration:none;color:#64748b;border:1px solid #e2e8f0;display:inline-flex;align-items:center;gap:6px}
.nav-pill:hover{background:#f1f5f9;color:#374151}.nav-pill.active{background:#4f46e5;color:#fff;border-color:#4f46e5}
.card{background:#fff;border-radius:10px;border:1px solid #e2e8f0;margin-bottom:20px;overflow:hidden}
.card-header{padding:14px 20px;border-bottom:1px solid #e2e8f0;display:flex;justify-content:space-between;align-items:center}
.card-title{font-size:15px;font-weight:600;color:#1e293b}
.sql-editor{width:100%;min-height:150px;padding:16px 20px;font-family:'Courier New',monospace;font-size:13px;border:none;border-bottom:1px solid #e2e8f0;resize:vertical;background:#0f172a;color:#e2e8f0;line-height:1.6}
.sql-editor:focus{outline:none}
.toolbar{padding:12px 20px;display:flex;justify-content:space-between;align-items:center;background:#f8fafc;gap:12px;flex-wrap:wrap}
.btn-run{background:#22c55e;color:#fff;border:none;padding:8px 20px;border-radius:6px;font-size:13px;font-weight:600;cursor:pointer;display:inline-flex;align-items:center;gap:6px}
.btn-run:hover{background:#16a34a}
table{width:100%;border-collapse:collapse}
th{text-align:left;padding:8px 12px;font-size:11px;font-weight:600;color:#64748b;text-transform:uppercase;background:#f8fafc;border-bottom:1px solid #e2e8f0;white-space:nowrap}
td{padding:8px 12px;font-size:12px;color:#374151;border-bottom:1px solid #f1f5f9;max-width:300px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
tr:hover td{background:#fafbfc}
.result-wrap{overflow-x:auto}
.result-info{padding:12px 20px;font-size:13px;color:#64748b;border-top:1px solid #e2e8f0;display:flex;justify-content:space-between}
.error-box{margin:16px 20px;background:#fef2f2;border:1px solid #fecaca;border-radius:8px;padding:12px 16px;color:#991b1b;font-size:13px;font-family:'Courier New',monospace}
.success-box{margin:16px 20px;background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;padding:12px 16px;color:#166534;font-size:13px}
.quick-queries{display:flex;gap:6px;flex-wrap:wrap}
.qq{padding:4px 10px;background:#f1f5f9;border-radius:4px;font-size:11px;color:#64748b;cursor:pointer;border:none;font-family:monospace}
.qq:hover{background:#e2e8f0;color:#374151}
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="page-header">
<div><h1 class="page-title"><i class="fas fa-terminal" style="color:#4f46e5"></i> SQL Query</h1></div>
<div class="nav-pills">
<a href="<?php echo e(route('admin.database.index')); ?>" class="nav-pill"><i class="fas fa-table"></i> Tables</a>
<a href="<?php echo e(route('admin.database.query')); ?>" class="nav-pill active"><i class="fas fa-terminal"></i> SQL Query</a>
<a href="<?php echo e(route('admin.database.export')); ?>" class="nav-pill"><i class="fas fa-download"></i> Export</a>
<a href="<?php echo e(route('admin.database.import')); ?>" class="nav-pill"><i class="fas fa-upload"></i> Import</a>
</div>
</div>

<div class="card">
<form method="POST" action="<?php echo e(route('admin.database.query')); ?>">
<?php echo csrf_field(); ?>
<textarea name="sql" class="sql-editor" placeholder="Enter SQL query here...&#10;Example: SELECT * FROM tbl_admin LIMIT 10"><?php echo e($sql); ?></textarea>
<div class="toolbar">
<div class="quick-queries">
<button type="button" class="qq" onclick="setQuery('SHOW TABLES')">SHOW TABLES</button>
<button type="button" class="qq" onclick="setQuery('SHOW TABLE STATUS')">TABLE STATUS</button>
<button type="button" class="qq" onclick="setQuery('SELECT VERSION()')">VERSION</button>
<button type="button" class="qq" onclick="setQuery('SHOW VARIABLES LIKE \'%max%\'')">MAX VARS</button>
<button type="button" class="qq" onclick="setQuery('SHOW PROCESSLIST')">PROCESSLIST</button>
</div>
<div style="display:flex;gap:8px;align-items:center">
<?php if($executionTime): ?><span style="font-size:12px;color:#94a3b8"><?php echo e($executionTime); ?>ms</span><?php endif; ?>
<button type="submit" class="btn-run"><i class="fas fa-play"></i> Execute (Ctrl+Enter)</button>
</div>
</div>
</form>

<?php if($error): ?>
<div class="error-box"><i class="fas fa-exclamation-circle"></i> <?php echo e($error); ?></div>
<?php endif; ?>

<?php if($affectedRows !== null): ?>
<div class="success-box"><i class="fas fa-check-circle"></i> Query executed. <?php echo e($affectedRows); ?> row(s) affected. (<?php echo e($executionTime); ?>ms)</div>
<?php endif; ?>

<?php if($results !== null): ?>
<div class="result-wrap">
<?php if(empty($results)): ?>
<div style="text-align:center;padding:30px;color:#94a3b8">No results returned.</div>
<?php else: ?>
<table>
<thead><tr><?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><th><?php echo e($col); ?></th><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></tr></thead>
<tbody>
<?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr><?php $__currentLoopData = (array)$row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><td <?php if(is_null($val)): ?>style="color:#d1d5db;font-style:italic"<?php endif; ?>><?php echo e(is_null($val) ? 'NULL' : \Illuminate\Support\Str::limit((string)$val, 100)); ?></td><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
<?php endif; ?>
</div>
<div class="result-info">
<span><?php echo e(count($results)); ?> row(s) returned</span>
<span><?php echo e($executionTime); ?>ms</span>
</div>
<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
function setQuery(q){document.querySelector('.sql-editor').value=q}
document.querySelector('.sql-editor').addEventListener('keydown',function(e){
if(e.ctrlKey&&e.key==='Enter'){e.preventDefault();this.closest('form').submit()}
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/mybusiness/office.mybusiness.com.my/resources/views/admin/pages/database/query.blade.php ENDPATH**/ ?>