<footer class="footer">
    <div>&copy; <?php echo e(date('Y')); ?> <strong>Admin Portal</strong>. All rights reserved.</div>
    <div>Version 1.0.0</div>
</footer>
<?php /**PATH /home/mybusiness/office.mybusiness.com.my/resources/views/admin/partials/menu_footer.blade.php ENDPATH**/ ?>