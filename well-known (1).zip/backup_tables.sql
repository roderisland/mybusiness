-- ============================================================
-- Backup Module Tables
-- Run this SQL if you already have the database set up
-- and only need to add the backup module tables
-- ============================================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

CREATE TABLE IF NOT EXISTS `tbl_backup_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `frequency` enum('daily','weekly','monthly','custom') NOT NULL DEFAULT 'daily',
  `cron_expression` varchar(50) DEFAULT NULL,
  `include_paths` json DEFAULT NULL,
  `exclude_paths` json DEFAULT NULL,
  `include_database` tinyint(1) NOT NULL DEFAULT 1,
  `retention_count` int(11) NOT NULL DEFAULT 10,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `last_run_at` timestamp NULL DEFAULT NULL,
  `next_run_at` timestamp NULL DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `tbl_backup_runs` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `job_id` bigint(20) UNSIGNED DEFAULT NULL,
  `folder_name` varchar(100) DEFAULT NULL,
  `status` enum('pending','running','completed','failed','restoring','restored') NOT NULL DEFAULT 'pending',
  `total_files` int(11) NOT NULL DEFAULT 0,
  `processed_files` int(11) NOT NULL DEFAULT 0,
  `total_size` bigint(20) NOT NULL DEFAULT 0,
  `include_paths` json DEFAULT NULL,
  `exclude_paths` json DEFAULT NULL,
  `include_database` tinyint(1) NOT NULL DEFAULT 1,
  `error_message` text DEFAULT NULL,
  `started_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_backup_runs_job_id` (`job_id`),
  KEY `idx_backup_runs_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `tbl_backup_logs` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `run_id` bigint(20) UNSIGNED NOT NULL,
  `level` enum('info','success','warning','error') NOT NULL DEFAULT 'info',
  `message` text NOT NULL,
  `file_path` varchar(500) DEFAULT NULL,
  `file_size` bigint(20) DEFAULT NULL,
  `logged_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_backup_logs_run_id` (`run_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
