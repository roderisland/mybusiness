# Migration Package for office.mybusiness.com.my

## How to Deploy

### Step 1: Import Database
Import `migration.sql` into your MySQL database via phpMyAdmin or CLI:
```
mysql -u username -p database_name < migration.sql
```

### Step 2: Copy Files
Extract and overwrite files into your Laravel project root:
```
- app/          → overwrite (controllers, middleware, models)
- bootstrap/    → overwrite (registers admin middleware)  
- config/       → overwrite auth.php, file-manager.php, filesystems.php only
- resources/    → overwrite (views)
- routes/       → overwrite (web.php + admin.php)
```

### Step 3: Update .env
Copy `.env.example` and update with your actual credentials:
- Database credentials (DB_HOST, DB_DATABASE, DB_USERNAME, DB_PASSWORD)
- APP_URL = https://office.mybusiness.com.my
- APP_TIMEZONE = Asia/Kuala_Lumpur
- Generate APP_KEY: `php artisan key:generate`

### Step 4: Clear Cache
```
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear
```

### Step 5: Login
- URL: https://office.mybusiness.com.my/admin/login
- Username: `admin`
- Password: `password123`
- **CHANGE THE PASSWORD AFTER FIRST LOGIN!**

## What's Included

### Admin Portal (from old project)
- Cookie-based admin authentication (login/logout)
- Role management (Administrator, Supervisor, Staff)
- Dynamic menu system with drag-and-drop ordering
- Role-based menu permissions (View/Create/Edit/Delete)
- Admin user CRUD
- File Manager page
- Placeholder pages: Reports, Settings, Activity Log

### Business Tables (from yewho_db)
- tbl_company, tbl_company_admin, tbl_company_admin_access_log
- tbl_company_admin_email_log, tbl_company_admin_role
- tbl_marketing_campaign, tbl_marketing_campaign_data, tbl_marketing_campaign_partner
- tbl_marketing_data
- tbl_partner, tbl_partner_access_log, tbl_partner_bankdetails, tbl_partner_email_log
- tbl_system_bank (seeded with 20 Malaysian banks)
- tbl_system_email_smtp, tbl_system_email_templates (seeded)

## File Structure
```
migration/
├── .env.example              ← Template for your .env
├── migration.sql             ← Full database (import this)
├── README.md                 ← This file
├── bootstrap/
│   └── app.php               ← Middleware registration
├── app/
│   ├── Http/
│   │   ├── Controllers/
│   │   │   └── Admin/        ← All admin controllers
│   │   └── Middleware/        ← 4 admin middleware files
│   ├── Models/                ← Admin, AdminRole, AdminMenu, etc.
│   └── Providers/
├── config/
│   ├── auth.php
│   ├── file-manager.php
│   └── filesystems.php
├── resources/views/
│   ├── welcome.blade.php
│   └── admin/                ← Full admin panel views
├── routes/
│   ├── web.php
│   └── admin.php
```

## Notes
- The File Manager feature requires the `alexusmai/laravel-file-manager` package
  Install via: `composer require alexusmai/laravel-file-manager`
- Update `config/filesystems.php` disk paths to match your server
- The admin authentication uses cookies (not Laravel sessions/guards)
- All admin tables use `tbl_` prefix
