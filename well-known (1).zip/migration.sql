-- ============================================================
-- Migration SQL for office.mybusiness.com.my
-- Generated: 2026-02-14
-- 
-- This file contains:
-- 1. Laravel system tables (users, sessions, cache, jobs)
-- 2. Admin portal tables (admin, roles, menus, permissions)
-- 3. Old business tables from yewho_db
-- 4. Seed data (banks, email templates, default admin user)
--
-- HOW TO USE:
-- 1. Create your MySQL database first
-- 2. Import this file via phpMyAdmin or mysql CLI:
--    mysql -u username -p database_name < migration.sql
-- 3. Update your .env with the DB credentials
-- 4. Default admin login: admin / password123
-- ============================================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

-- ============================================================
-- SECTION 1: LARAVEL SYSTEM TABLES
-- ============================================================

CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- SECTION 2: ADMIN PORTAL TABLES
-- ============================================================

CREATE TABLE IF NOT EXISTS `tbl_admin_roles` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `slug` varchar(50) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `level` int(11) NOT NULL DEFAULT 99,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tbl_admin_roles_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `tbl_admin` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `datetime_lastlogin` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tbl_admin_email_unique` (`email`),
  UNIQUE KEY `tbl_admin_username_unique` (`username`),
  KEY `tbl_admin_role_id_foreign` (`role_id`),
  CONSTRAINT `tbl_admin_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `tbl_admin_roles` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `tbl_admin_menu_groups` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tbl_admin_menu_groups_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `tbl_admin_menus` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `group_id` bigint(20) UNSIGNED NOT NULL,
  `parent_id` bigint(20) UNSIGNED DEFAULT NULL,
  `level` int(11) NOT NULL DEFAULT 1,
  `title` varchar(100) NOT NULL,
  `icon` varchar(50) DEFAULT NULL,
  `route_name` varchar(100) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `permission_key` varchar(100) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_admin_menus_group_id_foreign` (`group_id`),
  KEY `tbl_admin_menus_parent_id_foreign` (`parent_id`),
  CONSTRAINT `tbl_admin_menus_group_id_foreign` FOREIGN KEY (`group_id`) REFERENCES `tbl_admin_menu_groups` (`id`),
  CONSTRAINT `tbl_admin_menus_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `tbl_admin_menus` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `tbl_admin_role_menu_access` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `menu_id` bigint(20) UNSIGNED NOT NULL,
  `can_view` tinyint(1) NOT NULL DEFAULT 0,
  `can_create` tinyint(1) NOT NULL DEFAULT 0,
  `can_edit` tinyint(1) NOT NULL DEFAULT 0,
  `can_delete` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_menu_unique` (`role_id`, `menu_id`),
  KEY `tbl_admin_role_menu_access_menu_id_foreign` (`menu_id`),
  CONSTRAINT `tbl_admin_role_menu_access_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `tbl_admin_roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tbl_admin_role_menu_access_menu_id_foreign` FOREIGN KEY (`menu_id`) REFERENCES `tbl_admin_menus` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- SECTION 3: OLD BUSINESS TABLES (from yewho_db)
-- ============================================================

CREATE TABLE IF NOT EXISTS `tbl_company` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `datetime_register` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `username` mediumtext NOT NULL,
  `companyname` mediumtext NOT NULL,
  `code` mediumtext NOT NULL,
  `name` mediumtext NOT NULL,
  `email` mediumtext NOT NULL,
  `mobileno` varchar(13) NOT NULL,
  `email_verification_code` varchar(45) NOT NULL,
  `mobileno_verification_code` varchar(45) NOT NULL,
  `email_verified` enum('Yes','No') NOT NULL DEFAULT 'No',
  `mobileno_verified` enum('Yes','No') NOT NULL DEFAULT 'No',
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  `password` varchar(300) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `tbl_company_admin` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `datetime_registration` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `datetime_lastclick` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `datetime_lastlogin` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `companyid` int(10) UNSIGNED NOT NULL,
  `email` mediumtext NOT NULL,
  `password` mediumtext NOT NULL,
  `name` mediumtext NOT NULL,
  `roleid` int(10) UNSIGNED NOT NULL,
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Inactive',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `tbl_company_admin_access_log` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `datetime_login` datetime NOT NULL,
  `datetime_logout` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `datetime_lastclick` datetime NOT NULL,
  `adminid` int(10) UNSIGNED NOT NULL,
  `ip` mediumtext DEFAULT NULL,
  `hostname` mediumtext DEFAULT NULL,
  `country` mediumtext DEFAULT NULL,
  `state` mediumtext DEFAULT NULL,
  `city` mediumtext DEFAULT NULL,
  `postcode` mediumtext DEFAULT NULL,
  `latlong` mediumtext NOT NULL,
  `isp` mediumtext DEFAULT NULL,
  `platform` mediumtext DEFAULT NULL,
  `browser` mediumtext DEFAULT NULL,
  `version` mediumtext DEFAULT NULL,
  `useragent` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `tbl_company_admin_email_log` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `adminid` int(10) UNSIGNED NOT NULL,
  `smtpid` int(10) UNSIGNED NOT NULL,
  `subject` mediumtext NOT NULL,
  `content` mediumtext NOT NULL,
  `email_to` mediumtext NOT NULL,
  `email_cc` mediumtext DEFAULT NULL,
  `email_bcc` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `tbl_company_admin_role` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `companyid` int(10) UNSIGNED NOT NULL,
  `name` mediumtext NOT NULL,
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `tbl_marketing_campaign` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `companyid` int(10) UNSIGNED NOT NULL,
  `datetime` datetime NOT NULL,
  `descriptiom` mediumtext NOT NULL,
  `sql` mediumtext NOT NULL,
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `tbl_marketing_campaign_data` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `campaignid` int(10) UNSIGNED NOT NULL,
  `dataid` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `tbl_marketing_campaign_partner` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `campaignid` int(10) UNSIGNED NOT NULL,
  `partnerid` int(10) UNSIGNED NOT NULL,
  `status` enum('Active','Inactive') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `tbl_marketing_data` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `datetime` mediumtext NOT NULL,
  `rawdata` mediumtext NOT NULL,
  `orderno` mediumtext NOT NULL,
  `date_register` date NOT NULL,
  `date_activated` date NOT NULL,
  `companyname` mediumtext NOT NULL,
  `companycode` mediumtext NOT NULL,
  `name` mediumtext NOT NULL,
  `ic` mediumtext NOT NULL,
  `email` mediumtext NOT NULL,
  `email_pic` mediumtext NOT NULL,
  `tel` mediumtext NOT NULL,
  `hp` mediumtext NOT NULL,
  `hp_pic` mediumtext NOT NULL,
  `fax` mediumtext NOT NULL,
  `website` mediumtext NOT NULL,
  `packages` mediumtext NOT NULL,
  `houseno` mediumtext NOT NULL,
  `floorno` mediumtext NOT NULL,
  `building` mediumtext NOT NULL,
  `streetname` mediumtext NOT NULL,
  `postcode` mediumtext NOT NULL,
  `section` mediumtext NOT NULL,
  `city` mediumtext NOT NULL,
  `state` mediumtext NOT NULL,
  `branch` mediumtext NOT NULL,
  `partner` mediumtext NOT NULL,
  `ordertype` mediumtext NOT NULL,
  `orderstatus` mediumtext NOT NULL,
  `eformid` mediumtext NOT NULL,
  `installation` mediumtext NOT NULL,
  `lastupdatedatetime` mediumtext NOT NULL,
  `lastupdateby` int(10) UNSIGNED NOT NULL,
  `adminid` int(10) UNSIGNED NOT NULL,
  `status` enum('New','Follow Up','Completed','Closed') NOT NULL DEFAULT 'New',
  `cross_check` enum('Yes','No') NOT NULL DEFAULT 'No',
  `race` enum('None','Malay','Chinese','Indian','Others') NOT NULL DEFAULT 'None',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `tbl_partner` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `companyid` int(10) UNSIGNED NOT NULL,
  `datetime_registration` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `datetime_lastclick` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `datetime_lastlogin` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `email` mediumtext NOT NULL,
  `password` mediumtext NOT NULL,
  `mobileno` mediumtext NOT NULL,
  `name` mediumtext NOT NULL,
  `ic` varchar(14) NOT NULL,
  `email_verification_code` varchar(6) NOT NULL,
  `mobileno_verification_code` varchar(6) NOT NULL,
  `email_verified` enum('Yes','No') NOT NULL DEFAULT 'No',
  `mobileno_verified` enum('Yes','No') NOT NULL DEFAULT 'No',
  `wizard` enum('Yes','No') NOT NULL DEFAULT 'No',
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Inactive',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `tbl_partner_access_log` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `datetime_login` datetime NOT NULL,
  `datetime_logout` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `datetime_lastclick` datetime NOT NULL,
  `partnerid` int(10) UNSIGNED NOT NULL,
  `ip` mediumtext DEFAULT NULL,
  `hostname` mediumtext DEFAULT NULL,
  `country` mediumtext DEFAULT NULL,
  `state` mediumtext DEFAULT NULL,
  `city` mediumtext DEFAULT NULL,
  `postcode` mediumtext DEFAULT NULL,
  `latlong` mediumtext NOT NULL,
  `isp` mediumtext DEFAULT NULL,
  `platform` mediumtext DEFAULT NULL,
  `browser` mediumtext DEFAULT NULL,
  `version` mediumtext DEFAULT NULL,
  `useragent` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `partnerid` (`partnerid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `tbl_partner_bankdetails` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `partnerid` int(10) UNSIGNED NOT NULL,
  `bankid` int(10) UNSIGNED NOT NULL,
  `accountno` mediumtext NOT NULL,
  `default` enum('Yes','No') NOT NULL DEFAULT 'No',
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Inactive',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `tbl_partner_email_log` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `partnerid` int(10) UNSIGNED NOT NULL,
  `smtpid` int(10) UNSIGNED NOT NULL,
  `subject` mediumtext NOT NULL,
  `content` mediumtext NOT NULL,
  `email_to` mediumtext NOT NULL,
  `email_cc` mediumtext DEFAULT NULL,
  `email_bcc` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `tbl_system_bank` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` mediumtext NOT NULL,
  `status` enum('Enabled','Disabled','') NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `tbl_system_email_smtp` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `companyid` int(10) UNSIGNED NOT NULL,
  `description` mediumtext NOT NULL,
  `email` mediumtext NOT NULL,
  `host` mediumtext NOT NULL,
  `username` mediumtext NOT NULL,
  `password` mediumtext NOT NULL,
  `port` int(10) UNSIGNED NOT NULL,
  `ssl` enum('Yes','No') NOT NULL DEFAULT 'No',
  `from_name` mediumtext NOT NULL,
  `from_email` mediumtext NOT NULL,
  `reply_to` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `tbl_system_email_templates` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `smtpid` int(10) UNSIGNED NOT NULL,
  `description` mediumtext NOT NULL,
  `subject` mediumtext NOT NULL,
  `content` mediumtext NOT NULL,
  `email_to` mediumtext NOT NULL,
  `email_cc` mediumtext DEFAULT NULL,
  `email_bcc` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- SECTION 4: SEED DATA
-- ============================================================

-- Admin Roles
INSERT INTO `tbl_admin_roles` (`id`, `name`, `slug`, `description`, `level`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Administrator', 'administrator', 'Full system access', 1, 1, NOW(), NOW()),
(2, 'Supervisor', 'supervisor', 'Supervisory access', 2, 1, NOW(), NOW()),
(3, 'Staff', 'staff', 'Basic staff access', 3, 1, NOW(), NOW());

-- Default Admin User (password: password123)
INSERT INTO `tbl_admin` (`id`, `name`, `email`, `username`, `password`, `role_id`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Administrator', 'admin@mybusiness.com.my', 'admin', '$2y$12$mFVnuuZqQjXy0dj8hY3IneGvWK0P2JRzMVlT3cYJz4DzGmY5u6Iau', 1, 1, NOW(), NOW());

-- Menu Groups
INSERT INTO `tbl_admin_menu_groups` (`id`, `title`, `slug`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'MAIN MENU', 'main-menu', 0, 1, NOW(), NOW()),
(2, 'MANAGEMENT', 'management', 1, 1, NOW(), NOW()),
(3, 'SYSTEM', 'system', 2, 1, NOW(), NOW());

-- Menus
INSERT INTO `tbl_admin_menus` (`id`, `group_id`, `parent_id`, `level`, `title`, `icon`, `route_name`, `url`, `permission_key`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 1, NULL, 1, 'Dashboard', 'fas fa-home', 'admin.dashboard', NULL, 'dashboard', 0, 1, NOW(), NOW()),
(2, 2, NULL, 1, 'Admin Users', 'fas fa-users', 'admin.users.index', NULL, 'users', 0, 1, NOW(), NOW()),
(3, 2, NULL, 1, 'Roles', 'fas fa-user-tag', 'admin.roles.index', NULL, 'roles', 1, 1, NOW(), NOW()),
(4, 2, NULL, 1, 'Menu Management', 'fas fa-bars', 'admin.menus.index', NULL, 'menus', 2, 1, NOW(), NOW()),
(5, 2, NULL, 1, 'Permissions', 'fas fa-shield-alt', 'admin.permissions.index', NULL, 'permissions', 3, 1, NOW(), NOW()),
(6, 3, NULL, 1, 'Reports', 'fas fa-chart-bar', NULL, NULL, 'reports', 0, 1, NOW(), NOW()),
(7, 3, 6, 2, 'Sales Report', 'fas fa-dollar-sign', 'admin.reports.sales', NULL, 'reports.sales', 0, 1, NOW(), NOW()),
(8, 3, 6, 2, 'Analytics', 'fas fa-chart-line', 'admin.reports.analytics', NULL, 'reports.analytics', 1, 1, NOW(), NOW()),
(9, 3, NULL, 1, 'Settings', 'fas fa-cog', NULL, NULL, 'settings', 1, 1, NOW(), NOW()),
(10, 3, 9, 2, 'General', 'fas fa-sliders-h', 'admin.settings.general', NULL, 'settings.general', 0, 1, NOW(), NOW()),
(11, 3, 9, 2, 'Security', 'fas fa-lock', 'admin.settings.security', NULL, 'settings.security', 1, 1, NOW(), NOW()),
(12, 3, NULL, 1, 'File Manager', 'fas fa-folder-open', 'admin.filemanager.index', NULL, 'filemanager', 2, 1, NOW(), NOW()),
(13, 3, NULL, 1, 'Activity Log', 'fas fa-history', 'admin.activity-log', NULL, 'activity-log', 3, 1, NOW(), NOW()),
(14, 3, NULL, 1, 'Backup', 'fas fa-database', 'admin.backup.index', NULL, 'backup', 4, 1, NOW(), NOW()),
(15, 3, NULL, 1, 'Database', 'fas fa-server', 'admin.database.index', NULL, 'database', 5, 1, NOW(), NOW());

-- Malaysian Banks
INSERT INTO `tbl_system_bank` (`id`, `description`, `status`) VALUES
(1, 'Affin Bank', 'Enabled'),
(2, 'Al Rajhi Bank', 'Enabled'),
(3, 'Alliance Bank', 'Enabled'),
(4, 'AmBank', 'Enabled'),
(5, 'Bank Islam Malaysia', 'Enabled'),
(6, 'Bank Muamalat', 'Enabled'),
(7, 'Bank Negara Malaysia', 'Enabled'),
(8, 'Bank Kerjasama Rakyat', 'Enabled'),
(9, 'Bank Simpanan Nasional', 'Enabled'),
(10, 'CIMB Bank', 'Enabled'),
(11, 'CITI Bank', 'Enabled'),
(12, 'Hong Leong Bank', 'Enabled'),
(13, 'HSBC Bank', 'Enabled'),
(14, 'Malayan Banking Berhad', 'Enabled'),
(15, 'MAYBANK', 'Enabled'),
(16, 'OCBC Bank', 'Enabled'),
(17, 'Public Bank', 'Enabled'),
(18, 'RHB Bank', 'Enabled'),
(19, 'Standard Chartered Bank', 'Enabled'),
(20, 'United Overseas Bank', 'Enabled');

-- Email SMTP (update credentials for your new domain)
INSERT INTO `tbl_system_email_smtp` (`id`, `companyid`, `description`, `email`, `host`, `username`, `password`, `port`, `ssl`, `from_name`, `from_email`, `reply_to`) VALUES
(1, 1, 'Administrator', 'system@mybusiness.com.my', 'mail.mybusiness.com.my', 'system@mybusiness.com.my', 'CHANGE_ME', 587, 'Yes', 'System | MyBusiness', 'system@mybusiness.com.my', 'system@mybusiness.com.my');

-- Email Templates
INSERT INTO `tbl_system_email_templates` (`id`, `smtpid`, `description`, `subject`, `content`, `email_to`, `email_cc`, `email_bcc`) VALUES
(1, 1, 'Company Registration - New Registration Email', 'New User Registration', 'Dear [vendor_name], Thanks for registering as our user. We will need to verify your email and mobile number. Please check your next email and phone SMS. Thank you.', '[company_email]', '', 'system@mybusiness.com.my'),
(2, 1, 'Company Registration - Verify Email', 'Verifying Your Email Account', 'Dear [vendor_name], below is your email verification code [vendor_email_verification_code]', '[company_email]', '', 'system@mybusiness.com.my'),
(3, 1, 'Company Registration - Verify Email Successful', 'Verifying Your Email Successfully', 'Dear [vendor_name], your email address is verified successfully', '[company_email]', '', 'system@mybusiness.com.my'),
(4, 1, 'Company Registration - Verify MobileNo Successfully', 'Verifying Your MobileNo Successfully', 'Dear [company_name], your mobile number is verified successfully', '[company_email]', '', 'system@mybusiness.com.my'),
(5, 1, 'Company Registration - Account Activated', 'Account Activated', 'Dear [company_name], your account is activated.', '[company_email]', '', 'system@mybusiness.com.my'),
(6, 1, 'Company Registration - Reset Password', 'Reset Password', 'Dear [company_name], please click the link below to reset your password. Reset Here: [company_reset_password_link]', '[company_email]', '', 'system@mybusiness.com.my'),
(7, 1, 'Company Registration - Reset Password Successfully', 'Reset Password Successfully', 'Dear [company_name], your new password has been reset successfully. You can now use the new password to login. Thank you.', '[company_email]', '', 'system@mybusiness.com.my'),
(8, 1, 'Company Partners - Registration Notification', 'New Partner Has Joined', 'Dear [company_name], you have a new partner joined.', '[company_email]', '', 'system@mybusiness.com.my'),
(9, 1, 'Partners Registration - New Registration Email', 'New Partner Registration', 'Dear [partner_name], Thanks for registering as our partner. We will need to verify your email and mobile number.', '[partner_email]', '[company_email]', 'system@mybusiness.com.my'),
(10, 1, 'Partners Registration - Verify Email', 'Verifying Your Email Account - Partner', 'Dear [partner_name], below is your email verification code [partner_email_verification_code]', '[partner_email]', '[company_email]', 'system@mybusiness.com.my'),
(11, 1, 'Partners Registration - Verify Email Successful', 'Verifying Your Email Successfully - Partner', 'Dear [partner_name], your email address is verified successfully', '[partner_email]', '[company_email]', 'system@mybusiness.com.my'),
(12, 1, 'Partners Registration - Verify MobileNo Successfully', 'Verifying Your MobileNo Successfully - Partner', 'Dear [partner_name], your mobile number is verified successfully', '[partner_email]', '[company_email]', 'system@mybusiness.com.my'),
(13, 1, 'Partners Registration - Account Activated', 'Account Activated - Partner', 'Dear [partner_name], your account is activated.', '[partner_email]', '[company_email]', 'system@mybusiness.com.my'),
(14, 1, 'Partners Registration - Reset Password', 'Reset Password - Partner', 'Dear [partner_name], please click the link below to reset your password. Reset Here: [partner_reset_password_link]', '[partner_email]', '[company_email]', 'system@mybusiness.com.my'),
(15, 1, 'Partners Registration - Reset Password Successfully', 'Reset Password Successfully - Partner', 'Dear [partner_name], your new password has been reset successfully. You can now use the new password to login. Thank you.', '[partner_email]', '[company_email]', 'system@mybusiness.com.my');

-- ============================================================
-- SECTION 5: BACKUP MODULE TABLES
-- ============================================================

CREATE TABLE IF NOT EXISTS `tbl_backup_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `frequency` enum('daily','weekly','monthly','custom') NOT NULL DEFAULT 'daily',
  `cron_expression` varchar(50) DEFAULT NULL,
  `include_paths` json DEFAULT NULL,
  `exclude_paths` json DEFAULT NULL,
  `exclude_extensions` json DEFAULT NULL,
  `include_database` tinyint(1) NOT NULL DEFAULT 1,
  `retention_count` int(11) NOT NULL DEFAULT 10,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `last_run_at` timestamp NULL DEFAULT NULL,
  `next_run_at` timestamp NULL DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `tbl_backup_runs` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `job_id` bigint(20) UNSIGNED DEFAULT NULL,
  `folder_name` varchar(100) DEFAULT NULL,
  `status` enum('pending','running','completed','failed','restoring','restored') NOT NULL DEFAULT 'pending',
  `total_files` int(11) NOT NULL DEFAULT 0,
  `processed_files` int(11) NOT NULL DEFAULT 0,
  `total_size` bigint(20) NOT NULL DEFAULT 0,
  `include_paths` json DEFAULT NULL,
  `exclude_paths` json DEFAULT NULL,
  `exclude_extensions` json DEFAULT NULL,
  `include_database` tinyint(1) NOT NULL DEFAULT 1,
  `error_message` text DEFAULT NULL,
  `started_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_backup_runs_job_id` (`job_id`),
  KEY `idx_backup_runs_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `tbl_backup_logs` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `run_id` bigint(20) UNSIGNED NOT NULL,
  `level` enum('info','success','warning','error') NOT NULL DEFAULT 'info',
  `message` text NOT NULL,
  `file_path` varchar(500) DEFAULT NULL,
  `file_size` bigint(20) DEFAULT NULL,
  `logged_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_backup_logs_run_id` (`run_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
